﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : 
Author     : Jinesh Kumar C
Copyright  : Voleergo Technologies
Created on : 22/03/2018
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			By			
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

22/03/2018	Jinesh Kumar C		
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Log
{
    public class ErrorLogModel
    {

        public long ID_ErrorLog { get; set; }
        public byte Action { get; set; }
        public DateTime ErrLogDate { get; set; }
        public string Module { get; set; }
        public string ErrDetails { get; set; }
        public string ErrMessage { get; set; }
        public long EnteredBy { get; set; }
        public DateTime UserDate { get; set; }
        public string IPAddress { get; set; }
        public long FK_Client { get; set; }
        public long FK_ClientBranch { get; set; }

        public ErrorLogModel()
        {
            Initialize();
        }
        public void Initialize()
        {
            ID_ErrorLog = 0;
            Action = 0;
            ErrLogDate = DateTime.Now;
            Module = string.Empty;
            ErrDetails = string.Empty;
            ErrMessage = string.Empty;
            EnteredBy = 0;
            UserDate = DateTime.Now;
            IPAddress = string.Empty;
            FK_Client = 0;
            FK_ClientBranch = 0;
        }
    }
}
