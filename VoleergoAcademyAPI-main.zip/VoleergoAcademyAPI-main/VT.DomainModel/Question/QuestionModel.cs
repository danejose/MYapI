﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace VT.DomainModel.Question
{
    public class QuestionModel : BaseModel
    {

        [JsonProperty("id_MockInterview")]
        public int Id_MockInterview { get; set; }

      
        [JsonProperty("id_User")]
        public int Id_User { get; set; }

        [JsonProperty("id_Course")]
        public int Id_Course { get; set; }

        [JsonProperty("boolean")]
        public bool Enabled { get; set; }

        [JsonProperty("id_Question")] 
        public int Id_Question { get; set; }

        [JsonProperty("level")]
        public int Level { get; set; }

        [JsonProperty("levelname")]
        public string LevelName { get; set; }

        [JsonProperty("attemptedanswer")]
        public int AttemptedAnswer { get; set; }

        [JsonProperty("question")]
        public string Question { get; set; }

        [JsonProperty("option1")]
        public string Option1 { get; set; }

        [JsonProperty("option2")]
        public string Option2 { get; set; }

        [JsonProperty("option3")]
        public string Option3 { get; set; }

        [JsonProperty("option4")]
        public string Option4 { get; set; }

        [JsonProperty("answer")]
        public int Answer { get; set; }
        [JsonProperty("courseName")]
        public string CourseName { get; set; }





        public QuestionModel()
        {
            Id_User = 0;
            AttemptedAnswer = 0;
            Id_Question = 0;
            Id_Course = 0;
            Id_MockInterview = 0;
            Enabled=false;
            Question = string.Empty;
            Option1 = string.Empty;
            Option2 = string.Empty;
            Option3 = string.Empty;
            Option4 = string.Empty;
            Answer = 0;
            Level = 0;
            CourseName = string.Empty;
            LevelName = string.Empty;
        }

    }
}
