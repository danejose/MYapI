﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VT.DomainModel.Master
{
    public class CourseDomainModel
    {
        [JsonProperty("id")]
        public int ID { get; set; }

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("imageSrc")]
        public string ImageSrc {  get; set; }

        [JsonProperty("href")]
        public string Link { get; set; }

        [JsonProperty("description")]
        public string Description { get; set; }

        [JsonProperty("href1")]
        public string Href { get; set; }

        public CourseDomainModel()
        {
            ID = 0;
            Title = string.Empty;
            ImageSrc = string.Empty;
            Link = string.Empty;
            Description = string.Empty;
            Href = string.Empty;
        }

    }

    
}
