﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace VT.DomainModel.SearchUser
{
    public class SearchUserModel : BasicModel
    {
        [JsonProperty("id_user")]
        public string ID_User{ get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phone")]
        public string Phone {  get; set; }

        [JsonProperty("course")]
        public string Course {  get; set; }

        [JsonProperty("date")]
        public DateOnly Date { get; set; }



        public SearchUserModel() { 

            Name = string.Empty;
            Email = string.Empty;
            Phone = string.Empty;
            Course = string.Empty;
             
        }
    }
}
