﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VT.DomainModel.MockInterview
{
    public class MockInterviewModel
    {
        [JsonProperty("fk_MockInterviewQuestion")]
        public Int64 FK_MockInterviewQuestion { get; set; }

        [JsonProperty("fk_InterviewQuestions")]
        public Int64 FK_InterviewQuestions { get; set; }

        [JsonProperty("id_MockInterviewQuestionDetails")]
        public Int64 ID_MockInterviewQuestionDetails { get; set; }

        [JsonProperty("attendAnswer")]
        public Int64 AttendAnswer { get; set; }
        [JsonProperty("question")]
        public string Question { get; set; }

        [JsonProperty("option1")]
        public string Option1 { get; set; }

        [JsonProperty("option2")]
        public string Option2 { get; set; }

        [JsonProperty("option3")]
        public string Option3 { get; set; }

        [JsonProperty("option4")]
        public string Option4 { get; set; }

        [JsonProperty("completedTime")]
        public int CompletedTime { get; set; }
        public MockInterviewModel()
        {
            FK_MockInterviewQuestion = 0;
            FK_InterviewQuestions = 0;
            ID_MockInterviewQuestionDetails = 0;
            Question = string.Empty;
            Option1 = string.Empty;
            Option2 = string.Empty;
            Option3 = string.Empty;
            Option4 = string.Empty;
            AttendAnswer = 0;
            CompletedTime = 0;

        }
    }
}
