﻿using Newtonsoft.Json;
using System;

namespace VT.DomainModel.MockInterview
{
    public class DashboardSectionReviewList
    {
        [JsonProperty("idMockInterviewQuestionDetails")]
        public Int64 ID_MockInterviewQuestionDetails { get; set; }

        [JsonProperty("correctAnswer")]
        public string CorrectAnswer { get; set; }

        [JsonProperty("attendedAnswer")]
        public string AttendedAnswer { get; set; }

        [JsonProperty("idInterviewQuestions")]
        public Int64 ID_InterviewQuestions { get; set; }

        [JsonProperty("question")]
        public string Question { get; set; }

        [JsonProperty("option1")]
        public string Option1 { get; set; }

        [JsonProperty("option2")]
        public string Option2 { get; set; }

        [JsonProperty("option3")]
        public string Option3 { get; set; }

        [JsonProperty("option4")]
        public string Option4 { get; set; }

        public DashboardSectionReviewList()
        {
            ID_MockInterviewQuestionDetails = 0;
            CorrectAnswer = string.Empty;
            AttendedAnswer = string.Empty;
            ID_InterviewQuestions = 0;
            Question = string.Empty;
            Option1 = string.Empty;
            Option2 = string.Empty;
            Option3 = string.Empty;
            Option4 = string.Empty;
        }
    }
}
