﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VT.DomainModel.MockInterview
{
    public class DashboardSection
    {
        [JsonProperty("id_InterviewCourse")]
        public Int64 ID_InterviewCourse { get; set; }
        [JsonProperty("noofexamAttended")]
        public Int64 NoOfExamAttended { get; set; }

        [JsonProperty("markPercentage")]
        public decimal MarkPercentage { get; set; }

        [JsonProperty("courseName")]
        public string CourseName { get; set; }

        [JsonProperty("lastMarkPercentage")]
        public decimal LastMarkPercentage { get; set; }

        [JsonProperty("totalMarkPercentage")]
        public decimal TotalMarkPercentage { get; set; }
        [JsonProperty("isUpward")]
        public bool IsUpward { get; set; }

        public DashboardSection()
        {
            NoOfExamAttended = 0;
            MarkPercentage = 0;
            CourseName = string.Empty;
            LastMarkPercentage = 0;
            IsUpward = false;
            ID_InterviewCourse = 0;
        }
    }
}
