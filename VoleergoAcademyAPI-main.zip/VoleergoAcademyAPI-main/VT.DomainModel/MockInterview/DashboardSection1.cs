﻿using Newtonsoft.Json;
using System;

namespace VT.DomainModel.MockInterview
{
    public class DashboardSection1
    {
        [JsonProperty("idInterviewCourse")]
        public Int64 ID_InterviewCourse { get; set; }

        [JsonProperty("courseName")]
        public string CourseName { get; set; }

        [JsonProperty("interviewLevel")]
        public string InterviewLevel { get; set; }

        [JsonProperty("mark")]
        public Int64 MarkObtained { get; set; }

        [JsonProperty("id_MockInterviewQuestion")]
        public Int64 ID_MockInterviewQuestion { get; set; }

        [JsonProperty("percentageOfMarks")]
        public decimal PercenOfMarks { get; set; }

        [JsonProperty("completedTime")]
        public Int64 CompletedTime { get; set; }

        [JsonProperty("modifiedDate")]
        public DateTime ModifiedDate { get; set; }

        public DashboardSection1()
        {
            ID_InterviewCourse = 0;
            ID_MockInterviewQuestion = 0;
            CourseName = string.Empty;
            InterviewLevel = string.Empty;
            MarkObtained = 0;
            PercenOfMarks = 0;
            CompletedTime = 0;
            ModifiedDate = DateTime.MinValue;
        }
    }
}
