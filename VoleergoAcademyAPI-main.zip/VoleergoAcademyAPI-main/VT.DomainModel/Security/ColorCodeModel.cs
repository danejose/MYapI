﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Security
{
    public class ColorCodeModel : BasicModel
    {
        [JsonProperty(PropertyName = "id_ticketStatus")]
        public Int64 ID_TicketStatus { get; set; }

        [JsonProperty(PropertyName = "ticketStatusName")]
        public string TicketStatusName { get; set; }

        [JsonProperty(PropertyName = "colorName")]
        public string ColorName { get; set; }

        [JsonProperty(PropertyName = "colorCode")]
        public string ColorCode { get; set; }
  
        [JsonProperty(PropertyName = "class1")]
        public string Class1 { get; set; }

        [JsonProperty(PropertyName = "class2")]
        public string Class2 { get; set; }

        [JsonProperty(PropertyName = "class3")]
        public string Class3 { get; set; }

        [JsonProperty(PropertyName = "tableItems")]
        public string TableItems { get; set; }

        [JsonProperty(PropertyName = "fk_ColorCode")]
        public Int64 FK_ColorCode { get; set; }
        public ColorCodeModel()
        {
            ID_TicketStatus = 0;
            TicketStatusName = string.Empty;        
            ColorName = string.Empty;
            ColorCode = string.Empty;
            Class1 = string.Empty;
            Class2 = string.Empty;
            Class3 = string.Empty;
            TableItems = String.Empty;
            FK_ColorCode = 0;
        }
    }
}
