﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Security
{
    public class OneTimePassword
    {
        public string Category { get; set; }
        public Int64 FK_Users { get; set; }
        public Int64 FK_Trans { get; set; }
        public Int64 FK_ClientUnitSite { get; set; }
        public Int64 CreatedBy { get; set; }
        public Int64 ModifiedBy { get; set; }
        public Int64 OtpNumber { get; set; }

        public string Message { get; set; }

        public OneTimePassword()
        {
            Category=String.Empty;
            FK_Users=0;
            FK_Trans=0;
            FK_ClientUnitSite=0;
            CreatedBy = 0;
            ModifiedBy = 0;
            OtpNumber = 0;
            Message = string.Empty;
        }

    }
}
