﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Security
{
    public class RoleModel: BasicModel
    {
        [JsonProperty(PropertyName = "id_role")]
        public Int64 ID_Role { get; set; }

      
      
        [JsonProperty(PropertyName = "rolename")]
        public string RoleName { get; set; }
        
        [JsonProperty(PropertyName = "fk_Role")]
        public Int64 FK_Role { get; set; }

        [JsonProperty(PropertyName = "menuItems")]
        public string MenuItems { get; set; }

        [JsonProperty(PropertyName = "menugrpid")]
        public Int64 MenuGrpID { get; set; }

        [JsonProperty(PropertyName = "menuID")]
        public Int64 MenuID { get; set; }

        [JsonProperty(PropertyName = "menuName")]
        public string MenuName { get; set; }

        [JsonProperty(PropertyName = "isAdd")]
        public bool IsAdd { get; set; }
        [JsonProperty(PropertyName = "isEdit")]
        public bool IsEdit { get; set; }

        [JsonProperty(PropertyName = "isView")]
        public bool IsView { get; set; }

        [JsonProperty(PropertyName = "isDelete")]
        public bool IsDelete { get; set; }

        [JsonProperty(PropertyName = "user")]
        public Int64 UserId { get; set; }


        [JsonProperty(PropertyName = "rolePermissions")]
        public string RolePermissions { get; set; }

        [JsonProperty(PropertyName = "elementID")]
        public string ElementID { get; set; }

        [JsonProperty(PropertyName = "modules")]
        public string Modules { get; set; }

        [JsonProperty("fk_User")]
        public Int64 Fk_User { get; set; }

        [JsonProperty("fk_MenuAccess")]
        public Int64 FK_MenuAccess { get; set; }

        public RoleModel()
        {
            ID_Role = 0;
            FK_ClientUnitSite = 0;
            RoleName = string.Empty;
            IsActive = false;
            FK_Role = 0;
            MenuItems = string.Empty;
            MenuGrpID = 0;
            MenuID = 0;
            MenuName = string.Empty;
            IsAdd = false;
            IsEdit = false;
            IsView = false;
            IsDelete = false;
            UserId = 0;
            RolePermissions = string.Empty;
            ElementID = String.Empty;
            Modules = String.Empty;
            Fk_User = 0;
            FK_MenuAccess = 0;
        }
    }
}
