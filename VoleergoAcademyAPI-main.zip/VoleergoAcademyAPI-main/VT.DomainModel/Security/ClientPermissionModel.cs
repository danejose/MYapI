﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using VT.DomainModel;

namespace VT.DomainModel.Security
{
    public class ClientPermissionModel : BasicModel
    {
        [JsonProperty(PropertyName = "id_clientPageSecurables")]
        public Int64 ID_ClientPageSecurables { get; set; }

        [JsonProperty(PropertyName = "clientName")]
        public string ClientName { get; set; }

        [JsonProperty(PropertyName = "fk_Client")]
        public Int64 FK_Client { get; set; }

        [JsonProperty(PropertyName = "menuItems")]
        public string MenuItems { get; set; }

        [JsonProperty(PropertyName = "menugrpid")]
        public Int64 MenuGrpID { get; set; }

        [JsonProperty(PropertyName = "menuID")]
        public Int64 MenuID { get; set; }

        [JsonProperty(PropertyName = "menuName")]
        public string MenuName { get; set; }

        [JsonProperty(PropertyName = "isAdd")]
        public bool IsAdd { get; set; }
        [JsonProperty(PropertyName = "isEdit")]
        public bool IsEdit { get; set; }

        [JsonProperty(PropertyName = "isView")]
        public bool IsView { get; set; }

        [JsonProperty(PropertyName = "isDelete")]
        public bool IsDelete { get; set; }

        [JsonProperty(PropertyName = "user")]
        public Int64 UserId { get; set; }

        [JsonProperty(PropertyName = "clientPermissions")]
        public string ClientPermissions { get; set; }

        [JsonProperty(PropertyName = "elementID")]
        public string ElementID { get; set; }

        [JsonProperty(PropertyName = "modules")]
        public string Modules { get; set; }

        [JsonProperty("fk_User")]
        public Int64 Fk_User { get; set; }

        [JsonProperty("fk_MenuAccess")]
        public Int64 FK_MenuAccess { get; set; }
        public ClientPermissionModel()
        {
            ID_ClientPageSecurables = 0;
            FK_ClientUnitSite = 0;
            ClientName = string.Empty;
            IsActive = false;
            FK_Client = 0;
            MenuItems = string.Empty;
            MenuGrpID = 0;
            MenuID = 0;
            MenuName = string.Empty;
            IsAdd = false;
            IsEdit = false;
            IsView = false;
            IsDelete = false;
            UserId = 0;
            ClientPermissions = string.Empty;
            ElementID = String.Empty;
            Modules = String.Empty;
            Fk_User = 0;
            FK_MenuAccess = 0;
        }
    }
}
