﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Security
{
    public class ResetPasswordModel : BasicModel
    {
        [JsonProperty("id")]
        public Int64 ID_Users { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("emailID")]
        public string EmailID { get; set; }

        [JsonProperty("pwd")]
        public string Password { get; set; }
       
        [JsonProperty("epwd")]
        public string EncryptedPassword { get; set; }

        public ResetPasswordModel()
        {
            ID_Users = 0;
            EmailID = string.Empty;
            Name = string.Empty;
            UserName = string.Empty;
            Password = string.Empty;
            EncryptedPassword = string.Empty;

        }
    }
}

