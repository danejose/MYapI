﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace VT.DomainModel.Security
{
    public class UserModel : BasicModel
    {
        [JsonProperty("id")]
        public Int64 ID_Users { get; set; }       
        [JsonProperty("userCode")]
        public string UserCode { get; set; }
        [JsonProperty("firstName")]
        public string FirstName { get; set; }
        [JsonProperty("lastName")]
        public string LastName { get; set; }
        [JsonProperty("emailID")]
        public string EmailID { get; set; }
        [JsonProperty("pwd")]
        public string Password { get; set; }
        [JsonProperty("epwd")]
        public string EncryptedPassword { get; set; }
        [JsonProperty("fk_Language")]
        public Int64 FK_Language { get; set; }
        [JsonProperty("mobileNo")]
        public string MobileNumber { get; set; }
        [JsonProperty("lstLoginDateTime")]
        public DateTime LastLoginDateTime { get; set; }
        [JsonProperty("retryCount")]
        public Int64 RetryCount { get; set; }
        [JsonProperty("faCount")]
        public Int64 FailedAttemptCount { get; set; }
        [JsonProperty("lfaCount")]
        public Int64 LastFailedAttemptCount { get; set; }
        [JsonProperty("isGuest")]
        public Boolean IsGuest { get; set; }
        [JsonProperty("isOnlineUser")]
        public Boolean IsOnlineUser { get; set; }
        [JsonProperty("otp")]
        public Int64 OTPNumber { get; set; }
        [JsonProperty("userName")]
        public string UserName { get; set; }

        [JsonProperty("adminPanelAccess")]
        public Boolean AdminPanelAccess { get; set; }
        [JsonProperty("UserSecurables")]
        public string UserSecurables { get; set; }
        [JsonProperty("userRole")]
        public string UserRole { get; set; }

        [JsonProperty("newPassword")]
        public string NewPassword { get; set; }     

        [JsonProperty(PropertyName = "imageName")]
        public string ImageName { get; set; }

        [JsonProperty(PropertyName = "imgName")]
        public string ImgName { get; set; }
        [JsonProperty(PropertyName = "projectdetails")]
        public string ProjectDetails { get; set; }

        [JsonProperty("userType")]
        public Int64 UserType { get; set; }

        [JsonProperty("fromGoogle")]
        public Int16 FromGoogle { get; set; }


      
        [JsonProperty("company")]
        public string Company { get; set; }
        [JsonProperty(PropertyName = "clients")]
        public string Clients { get; set; }

        [JsonProperty("dob")]
        public string Dob { get; set; }

        [JsonProperty("countrycode")]
        public string CountryCode { get; set; }
        [JsonProperty("token")]
        public string? Token { get; set; }
        [JsonProperty("expiration")]
        public DateTime? Expiration { get; set; }
        [JsonProperty("sid")]
        public string? Sid { get; set; }

        public UserModel()
        {
            ID_Users = 0;
            FK_ClientUnitSite = 0;
            UserCode = string.Empty;
            EmailID = string.Empty;
            Password = string.Empty;
            FK_Language = 0;
            MobileNumber = string.Empty;
            LastLoginDateTime = DateTime.Now;
            RetryCount = 0;
            FailedAttemptCount = 0;
            LastFailedAttemptCount = 0;
            IsGuest = false;
            IsOnlineUser = false;
            Sid = string.Empty;
            EncryptedPassword = string.Empty;
            OTPNumber = 0;
            LastName = string.Empty;
            UserName = string.Empty;
            FromGoogle = 0;
            AdminPanelAccess = false;
            UserSecurables = string.Empty;
            UserRole = string.Empty;
            NewPassword = string.Empty;
            FK_Client = 0;
            ImageName = string.Empty;
            ImgName = string.Empty;
            ProjectDetails = String.Empty;
            UserType = 0;          
            Company = string.Empty;
            Clients = string.Empty;
            Token = string.Empty;
            Expiration = DateTime.Now;
        }
    }
}
