﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace VT.DomainModel.HR
{
    public class UserCourseDetails:BaseModel
    {
        
        [JsonProperty("id_UserCourseDetails")]
        public Int64 ID_UserCourseDetails { get; set; }
        [JsonProperty("id_user")]
        public Int64 ID_User { get; set; }
        [JsonProperty("courseName")]
        public string CourseName { get; set; }
        [JsonProperty("state")]
        public string State { get; set; }
        [JsonProperty("district")]
        public string District { get; set; }
        [JsonProperty("expectedJoinDate")]
        public DateTime ExpectedJoinDate { get; set; }
        [JsonProperty("courseType")]
        public string CourseType { get; set; }
        [JsonProperty("description")]
        public string Description { get; set; }
        [JsonProperty("fk_BatchType")]
        public Int64 FK_BatchType { get; set; }
        [JsonProperty("fk_CourseType")]
        public Int64 FK_CourseType { get; set; }
        [JsonProperty("fk_State")]
        public Int64 FK_State { get; set; }
        [JsonProperty("fk_District")]
        public Int64 FK_District { get; set; }
        [JsonProperty("batchTypeName")]
        public string BatchTypeName { get; set; }
        [JsonProperty("fk_Course")]
        public Int64 FK_Course { get; set; }
        [JsonProperty("transDate")]
        public DateTime TransDate { get; set; }
        [JsonProperty("transDateStr")]
        public string TransDateStr { get; set; }

        public UserCourseDetails() {

            ID_User = 0;
            CourseName = string.Empty;
            State = string.Empty;
            District = string.Empty;
            ExpectedJoinDate = DateTime.MinValue;
            CourseType = string.Empty;
            Description = string.Empty;
            BatchTypeName = string.Empty;
            ID_UserCourseDetails = 0;
            FK_State = 0;
            FK_District = 0;
            FK_State = 0;
            FK_CourseType = 0;
            FK_BatchType = 0;
            FK_Course = 0;
            TransDate = DateTime.Now;
            TransDateStr = string.Empty;
        }
    }
}
