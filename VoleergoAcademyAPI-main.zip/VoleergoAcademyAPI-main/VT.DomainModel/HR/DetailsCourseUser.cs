﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;


namespace VT.DomainModel.HR
{
    public class DetailsCourseUser : RegisteredUser
    {
        [JsonProperty("fk_district")]
        public Int64 FK_DISTRICT { get; set; }


        [JsonProperty("fk_Gender")]
        public Int64 FK_Gender { get; set; }

        [JsonProperty("fk_bloodGroup")]
        public Int64 FK_BloodGroup { get; set; }

        [JsonProperty("fk_IdProof")]
        public Int64 FK_IdProof { get; set; }
        [JsonProperty("course")]
        public string Course { get; set; }

        [JsonProperty("batch_type")]
        public string BatchType { get; set; }

        [JsonProperty("expected_join_date")]
        public DateTime ExpecJoinDate { get; set; }

        [JsonProperty("regid")]
        public string RegID { get; set; }

        public DetailsCourseUser()
        {
            ID_User = 0;
            Name = string.Empty;
            Email = string.Empty;
            PhoneNo = string.Empty;
            Description = string.Empty;
            District = string.Empty;
            State = string.Empty;
            Course = string.Empty;
            BatchType = string.Empty;
            CourseType = string.Empty;
            ExpecJoinDate = DateTime.Now;
            RegID = string.Empty;
        }
    }
}
