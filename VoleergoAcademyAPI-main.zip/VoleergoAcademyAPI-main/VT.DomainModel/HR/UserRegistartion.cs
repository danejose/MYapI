﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VT.DomainModel.HR
{
    public class UserRegistered : BaseModel
    {
        

        [JsonProperty("joinDate")]
        public DateTime JoinDate { get; set; }

        [JsonProperty("batchTypeName")]
        public string BatchTypeName { get; set; }
        [JsonProperty("course")]
        public string Course { get; set; }

        [JsonProperty("courseTypeName")]
        public string CourseTypeName { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("district")]
        public string District { get; set; }

        [JsonProperty("bloodGroup")]
        public string BloodGroup { get; set; }

        [JsonProperty("idProofName")]
        public string IDProofName { get; set; }

        [JsonProperty("gender")]
        public string Gender { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("address3")]
        public string Address3 { get; set; }

        [JsonProperty("pin")]
        public string PIN { get; set; }

        [JsonProperty("emergencyContact")]
        public string EmergencyContact { get; set; }

        [JsonProperty("pAddress1")]
        public string PAddress1 { get; set; }

        [JsonProperty("pAddress2")]
        public string PAddress2 { get; set; }

        [JsonProperty("pAddress3")]
        public string PAddress3 { get; set; }

        [JsonProperty("pPin")]
        public string PPIN { get; set; }

        [JsonProperty("idNumber")]
        public string ID_Number { get; set; }

        [JsonProperty("modifiedDate")]
        public DateTime ModifiedDate { get; set; }

        [JsonProperty("fk_batchType")]
        public Int64 FK_BatchType { get; set; }

        [JsonProperty("fk_courseType")]
        public Int64 FK_CourseType { get; set; }

        [JsonProperty("fk_course")]
        public Int64 FK_Course { get; set; }
        [JsonProperty("fk_User")]
        public Int64 FK_User { get; set; }

        [JsonProperty("fk_district")]
        public Int64 FK_District { get; set; }

        [JsonProperty("fk_state")]
        public Int64 FK_State { get; set; }

        [JsonProperty("fk_bloodGroup")]
        public Int64 FK_BloodGroup { get; set; }

        [JsonProperty("fk_gender")]
        public Int64 FK_Gender { get; set; }

        [JsonProperty("fk_idProof")]
        public Int64 FK_IdProof { get; set; }

        public UserRegistered()
        {
          ;
            
            JoinDate = DateTime.MinValue;
            BatchTypeName = string.Empty;
            CourseTypeName = string.Empty;
            Course= string.Empty;
            State = string.Empty;
            District = string.Empty;
            BloodGroup = string.Empty;
            IDProofName = string.Empty;
            Gender = string.Empty;
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            PIN = string.Empty;
            EmergencyContact = string.Empty;
            PAddress1 = string.Empty;
            PAddress2 = string.Empty;
            PAddress3 = string.Empty;
            PPIN = string.Empty;
            ID_Number = string.Empty;
            ModifiedDate = DateTime.MinValue;
            FK_BatchType = 0;
            FK_CourseType = 0;
            FK_Course = 0;
            FK_District = 0;
            FK_State = 0;
            FK_User = 0;    
            FK_BloodGroup = 0;
            FK_Gender = 0;
            FK_IdProof = 0;
        }
    }
}