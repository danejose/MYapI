﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace VT.DomainModel.HR
{
    public class RegisteredUser:UserCourseDetails
    {

        [JsonProperty("firstname")]
        public string FirstName { get; set; }
        [JsonProperty("lastname")]
        public string LastName { get; set; }
        [JsonProperty("email")]
        public string Email { get; set; }
        [JsonProperty("dob")]
        public DateTime Dob { get; set; }
        [JsonProperty("phone")]
        public string PhoneNo { get; set; }
        [JsonProperty("date")]
        public string Date { get; set; }

       
        [JsonProperty("id_course")]
        public Int64 ID_Course { get; set; }
        [JsonProperty("resumeurl")]
        public string ResumeUrl { get; set; }
        [JsonProperty("name")]
        public string Name { get; set; }

        public RegisteredUser() {
            ID_User = 0;
            FirstName = string.Empty;
            LastName = string.Empty;
            Email = string.Empty;
            Dob = DateTime.MinValue;
            PhoneNo = string.Empty;
            Date = string.Empty;
            Description = string.Empty;
            CourseName = string.Empty;
            ResumeUrl = string.Empty;
            PhoneNo = string.Empty;
        }

    }
}
