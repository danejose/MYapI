﻿using System;
using Newtonsoft.Json;

namespace VT.DomainModel.HR
{
    public class UserRegisteredCourse : BaseModel
    {
        [JsonProperty("regId")]
        public string RegId { get; set; }

        [JsonProperty("id_user")]
        public Int64 ID_UserRegistration { get; set; }

        [JsonProperty("uniqueId")]
        public string UniqueID { get; set; }

        [JsonProperty("joinDate")]
        public DateTime JoinDate { get; set; }

        [JsonProperty("fk_batchType")]
        public int FK_BatchType { get; set; }

        [JsonProperty("fk_courseType")]
        public int FK_CourseType { get; set; }

        [JsonProperty("fk_user")]
        public int FK_User { get; set; }

        [JsonProperty("fk_state")]
        public int FK_State { get; set; }

        [JsonProperty("fk_district")]
        public int FK_DISTRICT { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phoneNo")]
        public string PhoneNo { get; set; }

        [JsonProperty("courseName")]
        public string CourseName { get; set; }

        [JsonProperty("id_course")]
        public Int64 ID_Course { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("address3")]
        public string Address3 { get; set; }

        [JsonProperty("pin")]
        public string PIN { get; set; }

        [JsonProperty("pAddress1")]
        public string PAddress1 { get; set; }

        [JsonProperty("pAddress2")]
        public string PAddress2 { get; set; }

        [JsonProperty("pAddress3")]
        public string PAddress3 { get; set; }

        [JsonProperty("pPin")]
        public string PPIN { get; set; }

        [JsonProperty("emergencyContact")]
        public string EmergencyContact { get; set; }

        [JsonProperty("fk_bloodGroup")]
        public int FK_BloodGroup { get; set; }

        [JsonProperty("fk_idProof")]
        public int FK_IdProof { get; set; }

        [JsonProperty("id_number")]
        public string ID_Number { get; set; }

        [JsonProperty("fk_gender")]
        public int FK_Gender { get; set; }

        public UserRegisteredCourse()
        {
            RegId = string.Empty;
            ID_UserRegistration = 0;
            UniqueID = string.Empty;
            JoinDate = DateTime.MinValue;
            FK_BatchType = 0;
            FK_CourseType = 0;
            FK_User = 0;
            FK_State = 0;
            FK_DISTRICT = 0;
            Name = string.Empty;
            Email = string.Empty;
            PhoneNo = string.Empty;
            CourseName = string.Empty;
            ID_Course = 0;
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            PIN = string.Empty;
            PAddress1 = string.Empty;
            PAddress2 = string.Empty;
            PAddress3 = string.Empty;
            PPIN = string.Empty;
            EmergencyContact = string.Empty;
            FK_BloodGroup = 0;
            FK_IdProof = 0;
            ID_Number = string.Empty;
            FK_Gender = 0;
        }
    }
}
