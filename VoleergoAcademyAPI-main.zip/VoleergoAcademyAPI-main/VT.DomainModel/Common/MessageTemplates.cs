﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Common
{
    public static class MessageTemplates
    {
        public const string New_Message_Template = "new_message_create_template";
        public const string Auto_Message_Template = "reply_template";
        public const string New_Ticket_Request = "new_ticket_request";
        public const string View_Ticket_Template = "view_ticket_tmpl_new";
        public const string View_Ticket_NoData_Template = "view_ticket_nodata";
        public const string Auto_Reply_Template = "auto_reply";
        public const string Add_Comments_Message = "add_comments_message";
        public const string Add_Comment_Template_View = "add_comment_view_template";

        public const string Campus_Welcome = "campus_welcome";
        public const string Campus_SendtoGroup = "campus_sendtogroup";

        public const string Voleergo_Intern = "voleergo_intern_1";


    }


    public static class MessageText
    {
        public const string Message_CreateNew = "Create New";
        public const string Message_ViewTicket = "View Ticket";
        public const string Message_AddComments = "Add Comments";
    }

    public static class MessageType
    {
        public const string Message_CreateNew_Ticket = "TCKREQ";
        public const string Message_CreateNew_Comment = "CMNTSEND";
       
    }
    public static class WhatupMessageType
    {
        public const string Message_Text = "text";
        public const string Message_Document = "document";
        public const string Message_Image = "image";

    }
}
