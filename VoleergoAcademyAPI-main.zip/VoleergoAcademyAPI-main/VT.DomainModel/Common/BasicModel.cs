﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace VT.DomainModel
{
    public abstract class BasicModel
    {
        [JsonProperty("ipAddress")]
        public string IPAddress { get; set; }
        [JsonProperty("browser")]
        public string Browser { get; set; }
        [JsonProperty("isMobile")]
        public Boolean IsMobile { get; set; }       
        [JsonProperty("fk_ClientBranch")]
        public long FK_ClientBranch { get; set; }
        [JsonProperty("FK_businessClient")]
        public Int64 FK_BusinessClient { get; set; }
        [JsonProperty("fk_ClientUnit")]
        public Int64 FK_ClientUnit { get; set; }    
        [JsonProperty("fk_ClientUnitSite")]
        public Int64 FK_ClientUnitSite { get; set; }
        [JsonProperty("createdDate")]
        public DateTime CreatedDate { get; set; }
        [JsonProperty("createdBy")]
        public long CreatedBy { get; set; }
        [JsonProperty("modifiedDate")]
        public DateTime ModifiedDate { get; set; }
        [JsonProperty("modifiedBy")]
        public long ModifiedBy { get; set; }
        [JsonProperty("cancelled")]
        public Boolean Cancelled { get; set; }
        [JsonProperty("cancelledOn")]
        public DateTime CancelledOn { get; set; }
        [JsonProperty("cancelledBy")]
        public long CancelledBy { get; set; }
        [JsonProperty("invalid")]
        public Boolean Invalid { get; set; }
        [JsonProperty("isActive")]
        public Boolean IsActive { get; set; }

        [JsonProperty("msgCode")]
        public Int64 MessageCode { get; set; }
        [JsonProperty("msgText")]
        public string MessageText { get; set; }
        [JsonProperty("msgType")]
        public string MessageType { get; set; }
        [JsonIgnore]
        public string ActionMode { get; set; }

        [JsonProperty("searchField")]
        public string SearchField { get; set; }
        [JsonProperty("searchValue")]
        public string SearchValue { get; set; }

        [JsonProperty(PropertyName = "user")]
        public Int64 UserId { get; set; }

        [JsonProperty(PropertyName = "userProfileImage")]
        public string UserProfileImage { get; set; }
        [JsonProperty(PropertyName = "createdUserEmail")]
        public string CreatedUserEmail { get; set; }
        [JsonProperty("fk_Client")]
        public Int64 FK_Client { get; set; }

        [JsonProperty(PropertyName = "createdUserMobileNumber")]
        public string CreatedUserMobileNumber { get; set; }
        public BasicModel()
        {
            IPAddress = string.Empty;
            FK_ClientBranch = 0;
            CreatedDate = DateTime.Now;
            CreatedBy = 0;
            ModifiedDate = DateTime.Now;
            ModifiedBy = 0;
            Cancelled = false;
            CancelledOn = DateTime.Now;
            CancelledBy = 0;
            Invalid = false;
            IsActive = true;
            MessageCode = 0;
            MessageText = string.Empty;
            MessageType = string.Empty;

            Browser = string.Empty;
            IsMobile = false;
            ActionMode = string.Empty;

            SearchField = string.Empty;
            SearchValue = string.Empty;
            UserId = 0;
            UserProfileImage = string.Empty;
            CreatedUserEmail = string.Empty;
            FK_Client = 0;
            CreatedUserMobileNumber = string.Empty;
        }
    }
}
