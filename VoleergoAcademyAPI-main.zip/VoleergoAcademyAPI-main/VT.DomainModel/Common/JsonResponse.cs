﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Common
{
    public class JsonResponse
    {
        [JsonProperty("data")]
        public string Data { get; set; }
        
        public JsonResponse()
        {
            Data = string.Empty;
        }
    }
}
