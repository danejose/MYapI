﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Common
{
    public class ResponseStatusResult
    {
        [JsonProperty("result")]
        public ResponseStatus Result { get; set; }
    }
}
