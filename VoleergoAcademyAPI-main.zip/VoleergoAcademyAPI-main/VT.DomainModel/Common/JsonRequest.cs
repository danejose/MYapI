﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Common
{
    public class JsonRequest
    {
        [JsonProperty("data")]
        public string Data { get; set; }
        
        public JsonRequest()
        {
            Data = string.Empty;
        }
    }
}
