﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Common
{
    public class ResponseStatus
    {
        [JsonProperty(PropertyName = "returnCode")]
        public string ReturnCode { get; set; }
        [JsonProperty(PropertyName = "returnMessage")]
        public string ReturnMessage { get; set; }
        [JsonProperty("trackingNumber")]
        public string TrackingNumber { get; set; }

        public ResponseStatus()
        {
            ReturnCode = string.Empty;
            ReturnMessage = string.Empty;
            TrackingNumber = string.Empty;
        }
    }
}
