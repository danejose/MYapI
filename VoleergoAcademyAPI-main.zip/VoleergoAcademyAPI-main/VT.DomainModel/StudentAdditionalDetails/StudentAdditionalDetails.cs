﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using VT.DomainModel.SearchUser;

namespace VT.DomainModel.StudentAdditionalDetails
{
    public class StudentAdditionalDetails : SearchUserModel
    {
        [JsonProperty("joinDate")]
        public DateTime JoinDate { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("address3")]
        public string Address3 { get; set; }

        [JsonProperty("addressType")]
        public string AddressType { get; set; }

        [JsonProperty("pin")]
        public int PIN { get; set; }

        [JsonProperty("id_Number")]
        public string ID_Number { get; set; }

        [JsonProperty("fk_User")]
        public int FK_User { get; set; }

        [JsonProperty("fk_Course")]
        public int FK_Course { get; set; }
        [JsonProperty("fk_IDType")]
        public int FK_IDType { get; set; }

        [JsonProperty("fk_BloodGroup")]
        public int FK_BloodGroup { get; set; }
        [JsonProperty("fk_BatchType")]
        public int FK_BatchType { get; set; }
        [JsonProperty("fk_CourseType")]
        public int FK_CourseType { get; set; }
        [JsonProperty("emergencyContact")]
        public int EmergencyContact { get; set; }
        [JsonProperty("dob")]
        public DateTime DOB { get; set; }
        public StudentAdditionalDetails()
        {
            JoinDate= DateTime.Now;
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            AddressType = string.Empty;
            ID_Number=string.Empty;
            PIN = 0;
            FK_User = 0;
            FK_Course = 0;
            FK_IDType = 0;
            FK_BloodGroup = 0;
            FK_BatchType = 0;
            FK_CourseType = 0;
            DOB= DateTime.Now;
            EmergencyContact = 0;
        }
    }
}
