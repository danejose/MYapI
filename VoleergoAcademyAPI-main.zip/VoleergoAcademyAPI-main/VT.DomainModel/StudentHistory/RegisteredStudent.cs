﻿using Newtonsoft.Json;
using System;

namespace VT.DomainModel.StudentHistory
{
    public class RegisteredStudent
    {
        [JsonProperty("Address1")]
        public string Address1 { get; set; }

        [JsonProperty("Address2")]
        public string Address2 { get; set; }

        [JsonProperty("Address3")]
        public string Address3 { get; set; }

        [JsonProperty("AddressType")]
        public string AddressType { get; set; }

        [JsonProperty("Pin")]
        public int? PIN { get; set; }

        [JsonProperty("EmergencyContact")]
        public long? EmergencyContact { get; set; }

        [JsonProperty("FK_State")]
        public int? FK_State { get; set; }

        [JsonProperty("FK_District")]
        public int? FK_District { get; set; }

        [JsonProperty("FK_User")]
        public int? FK_User { get; set; }

        [JsonProperty("ExpecJoinDate")]
        public DateTime? ExpecJoinDate { get; set; }

        [JsonProperty("FK_BatchType")]
        public int? FK_BatchType { get; set; }

        [JsonProperty("FK_CourseType")]
        public int? FK_CourseType { get; set; }

        [JsonProperty("FK_Course")]
        public int? FK_Course { get; set; }

        [JsonProperty("ModifiedBy")]
        public int? ModifiedBy { get; set; }

        public RegisteredStudent()
        {
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            AddressType = string.Empty;
            PIN = null;
            EmergencyContact = null;
            FK_State = null;
            FK_District = null;
            FK_User = null;
            ExpecJoinDate = null;
            FK_BatchType = null;
            FK_CourseType = null;
            FK_Course = null;
            ModifiedBy = null;
        }
    }
}
