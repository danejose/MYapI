﻿using Newtonsoft.Json;
using System;

namespace VT.DomainModel.StudentHistory
{
    public class CourseRegisteredStudent
    {
        [JsonProperty("lastName")]
        public string LastName { get; set; }

        [JsonProperty("firstName")]
        public string FirstName { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("phoneNo")]
        public string PhoneNo { get; set; }

        [JsonProperty("joinDate")]
        public DateTime? JoinDate { get; set; }

        [JsonProperty("address1")]
        public string Address1 { get; set; }

        [JsonProperty("address2")]
        public string Address2 { get; set; }

        [JsonProperty("address3")]
        public string Address3 { get; set; }

        [JsonProperty("addressType")]
        public string AddressType { get; set; }

        [JsonProperty("pin")]
        public int? PIN { get; set; }

        [JsonProperty("id_Number")]
        public string ID_Number { get; set; }

        [JsonProperty("fk_User")]
        public int? FK_User { get; set; }

        [JsonProperty("fk_Course")]
        public int? FK_Course { get; set; }

        [JsonProperty("fk_IdType")]
        public int? FK_IdType { get; set; }
        [JsonProperty("id_UserRegistration")]
        public int? ID_UserRegistration { get; set; }

        [JsonProperty("fk_BloodGroup")]
        public int? FK_BloodGroup { get; set; }

        [JsonProperty("fk_BatchType")]
        public int? FK_BatchType { get; set; }

        [JsonProperty("fk_CourseType")]
        public int? FK_CourseType { get; set; }

        [JsonProperty("fk_Gender")]
        public int? FK_Gender { get; set; }

        [JsonProperty("fk_State")]
        public int? FK_State { get; set; }

        [JsonProperty("fk_District")]
        public int? FK_District { get; set; }

        [JsonProperty("emergencyContact")]
        public long? EmergencyContact { get; set; }

        [JsonProperty("dob")]
        public DateTime? Dob { get; set; }

        [JsonProperty("fk_UserRegistration")]
        public int? FK_UserRegistration { get; set; }

        [JsonProperty("regId")]
        public string RegId { get; set; }

        [JsonProperty("modifiedDate")]
        public DateTime? ModifiedDate { get; set; }

        [JsonProperty("modifiedBy")]
        public int? ModifiedBy { get; set; }


        [JsonProperty("paddress1")]
        public string PAddress1 { get; set; }

        [JsonProperty("paddress2")]
        public string PAddress2 { get; set; }

        [JsonProperty("paddress3")]
        public string PAddress3 { get; set; }
        [JsonProperty("ppin")]
        public int? PPIN { get; set; }
        public CourseRegisteredStudent()
        {
            LastName = string.Empty;
            FirstName = string.Empty;
            Email = string.Empty;
            PhoneNo = string.Empty;
            JoinDate = DateTime.Now;
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            AddressType = string.Empty;
            PIN = 0;
            ID_Number = string.Empty;
            FK_User = 0;
            FK_Course = 0;
            FK_IdType = 0;
            FK_BloodGroup = 0;
            FK_BatchType = 0;
            FK_CourseType = 0;
            FK_Gender = 0;
            FK_State = 0;
            FK_District = 0;
            EmergencyContact = 0;
            Dob = DateTime.Now;
            FK_UserRegistration = 0;
            RegId = string.Empty;
            ModifiedDate = null;
            ModifiedBy = null;
            PAddress1 = string.Empty;
            PAddress2 =string.Empty;
            PAddress3 = string.Empty;
            PPIN = 0;
        }
    }
}
