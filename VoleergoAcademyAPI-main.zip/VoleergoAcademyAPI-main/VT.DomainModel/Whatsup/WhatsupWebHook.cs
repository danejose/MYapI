﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class WhatsupWebHook
    {
        public long ID_WhatsupWebHook { get; set; }
        public string MobileNumber { get; set; }
        public string ColumnValue { get; set; }
        public string WhatsappMessageId { get; set; }
        public string MessageType { get; set; }
        public string ReplyContextId { get; set; }
        public string FK_Ticket { get; set; }
        public string Response { get; set; }

        public WhatsupWebHook()
        {
            ID_WhatsupWebHook = 0;
            MobileNumber = string.Empty;
            ColumnValue = string.Empty; 
            WhatsappMessageId = string.Empty;
            MessageType = string.Empty;
            ReplyContextId = string.Empty;
            MessageType = string.Empty;
            FK_Ticket = string.Empty;
            Response = string.Empty;

        }
    }
}
