﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class TemplateMessage
    {
        public string template_name { get; set; }
        public string broadcast_name { get; set; }
        public List<TemplateMessageParams> parameters { get; set; }

        public TemplateMessage()
        {
            template_name = string.Empty;
            broadcast_name = string.Empty;
            parameters = new List<TemplateMessageParams>();
        }
    }
    public class TemplateMessageParams
    {
        public string name { get; set; }
        public string value { get; set; }

        public TemplateMessageParams()
        {
            name = string.Empty;
            value = string.Empty;
        }
    }
    public class SessionMessage
    {
        public string messageText { get; set; }

        public SessionMessage()
        {
            messageText = string.Empty;
        }

    }




    public class TemplateMessageGroup
    {
        public string template_name { get; set; }

        public string broadcast_name { get; set; }

        public List<Receiver> receivers { get; set; }

        public TemplateMessageGroup()
        {
            template_name = string.Empty;
            broadcast_name = string.Empty;
            receivers = new List<Receiver>();
        }
    }

    public class Receiver
    {
        public string whatsappNumber { get; set; }
        public List<TemplateMessageParams> customParams { get; set; }
        public Receiver()
        {
            whatsappNumber = string.Empty;
            customParams = new List<TemplateMessageParams>();
        }
    }


}
