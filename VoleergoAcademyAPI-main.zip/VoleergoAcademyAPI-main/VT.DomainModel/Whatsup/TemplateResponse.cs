﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class TemplateResponse
    {
        public bool result { get; set; }
        public string phone_number { get; set; }
        public string template_name { get; set; }
        public bool validWhatsAppNumber { get; set; }       
        public TemplateResponse()
        {
            result = false;
            phone_number = string.Empty;
            template_name = string.Empty;
            validWhatsAppNumber = false;
        }
    }
}
