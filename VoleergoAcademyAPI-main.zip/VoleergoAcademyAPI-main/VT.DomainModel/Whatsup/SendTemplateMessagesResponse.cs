﻿/*----------------------------------- SendTemplateMessagesResponse Class-----------------------------------------------------------------------------------------------------------------------
  Purpose    : SendTemplateMessagesResponse
  Author     : Jinesh Kumar C
  Copyright  :
  Created on : 11-08-2023 11:50:20
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  MODIFICATIONS 
  On                             By
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  11-08-2023 11:50:20       Jinesh Kumar C
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class SendTemplateMessagesResponse
    {

        public bool Result { get; set; }
        public Errors Errors { get; set; }
        public SendTemplateMessagesResponse()
        {
            Result = false;
            Errors = new Errors();
        }

    }

    public class Errors
    {
        public string Error { get; set; }
        public IList<object> InvalidWhatsappNumbers { get; set; }
        public IList<object> InvalidCustomParameters { get; set; }
        public Errors()
        {
            Error = string.Empty;
            InvalidWhatsappNumbers = new List<object>();
            InvalidCustomParameters = new List<object>();
        }
    }
}
