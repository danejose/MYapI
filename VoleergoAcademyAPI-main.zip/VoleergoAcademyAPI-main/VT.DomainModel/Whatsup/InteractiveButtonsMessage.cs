﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class InteractiveButtonsMessage
    {
        public Header header { get; set; }

        public string body { get; set; }

        public string footer { get; set; }

        public IList<Button> buttons { get; set; }

        public InteractiveButtonsMessage()
        {
            header = new Header();
            body = string.Empty;
            footer = string.Empty;
            buttons = new List<Button>();
        } 
    }
    public class Media
    {

        public string url { get; set; }

        public string fileName { get; set; }

        public Media()
        {
            url = string.Empty;
            fileName = string.Empty;
        }
    }
    public class Button
    {
        public string text { get; set; }
        public Button()
        {
            text = string.Empty;
        }
    }
    public class Header
    {

        public string type { get; set; }
        public string text { get; set; }

        public Header()
        {
            type = string.Empty;
            text = string.Empty;
        }
    }
}