﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class WhatsupCallback
    {
        public string id { get; set; }
        public string text { get; set; }
        public string senderName { get; set; }
        public string created { get; set; }
        public string whatsappMessageId { get; set; }
        public string conversationId { get; set; }
        public string ticketId { get; set; }
        public string type { get; set; }
        public string data { get; set; }
        public string sourceId { get; set; }
        public string sourceUrl { get; set; }
        public string timestamp { get; set; }
        public string owner { get; set; }
        public string eventType { get; set; }
        public string statusString { get; set; }
        public string avatarUrl { get; set; }
        public string assignedId { get; set; }
        public string operatorName { get; set; }
        public string operatorEmail { get; set; }
        public string waId { get; set; }
        public string messageContact { get; set; }
        public string listReply { get; set; }
        public string replyContextId { get; set; }      

        public WhatsupCallback()
        {
            id=string.Empty;
            text=string.Empty;
            senderName = string.Empty;
            created = string.Empty;
            whatsappMessageId = string.Empty;
            conversationId = string.Empty;
            ticketId = string.Empty;
            type = string.Empty;
            data = string.Empty;
            sourceId = string.Empty;
            sourceUrl = string.Empty;
            timestamp = string.Empty;
            owner = string.Empty;
            eventType = string.Empty;
            statusString = string.Empty;
            avatarUrl = string.Empty;
            assignedId = string.Empty;
            operatorName = string.Empty;
            operatorEmail = string.Empty;
            waId = string.Empty;
            messageContact = string.Empty;
            listReply = string.Empty;
            replyContextId = string.Empty;
            type = string.Empty;
            data = string.Empty;
            sourceId = string.Empty;
            sourceUrl = string.Empty;
            timestamp = string.Empty;
            owner = string.Empty;
            eventType = string.Empty;

        }
    }
}
