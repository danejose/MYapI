﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class WhatsupSettings
    {
        public bool EnableWhatsup { get; set; }
        public string WhatupsURL { get; set; }
        public string WhatupsNumber { get; set; }
        public string WhatupsToken { get; set; }

        public WhatsupSettings()
        {
            EnableWhatsup = false;
            WhatupsURL = string.Empty;
            WhatupsNumber = string.Empty;
            WhatupsToken = string.Empty;
        }
    }
}
