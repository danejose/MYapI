﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.DomainModel.Whatsup
{
    public class InteractiveButtonsMessageResponse
    {
        public bool ok { get; set; }
        public IList<object> errors { get; set; }
        public Message message { get; set; }
        public InteractiveButtonsMessageResponse()
        {
            ok = false;
            errors = new List<object>();
            message = new Message();
        }
    }
    public class Message
    {
        public string whatsappMessageId { get; set; }
        public string localMessageId { get; set; }
        public string text { get; set; }
        public object media { get; set; }
        public object messageContact { get; set; }
        public object location { get; set; }
        public string type { get; set; }
        public string time { get; set; }
        public int status { get; set; }
        public string statusString { get; set; }
        public bool isOwner { get; set; }
        public bool isUnread { get; set; }
        public string ticketId { get; set; }
        public object avatarUrl { get; set; }
        public string assignedId { get; set; }
        public string operatorName { get; set; }
        public object replyContextId { get; set; }
        public int sourceType { get; set; }
        public object failedDetail { get; set; }
        public object messageReferral { get; set; }
        public object messageProducts { get; set; }
        public object orderProducts { get; set; }
        public string id { get; set; }
        public DateTime created { get; set; }
        public string conversationId { get; set; }
        public Message()
        {
            whatsappMessageId = string.Empty;
            localMessageId = string.Empty;
            text = string.Empty;
            media = string.Empty; ;
            messageContact = string.Empty; ;
            location = string.Empty; ;
            type = string.Empty;
            time = string.Empty;
            status = 0;
            statusString = string.Empty;
            isOwner = false;
            isUnread = false;
            ticketId = string.Empty;
            avatarUrl = string.Empty; ;
            assignedId = string.Empty;
            operatorName = string.Empty;
            replyContextId = string.Empty; ;
            sourceType = 0;
            failedDetail = string.Empty; ;
            messageReferral = string.Empty; ;
            messageProducts = string.Empty; ;
            orderProducts = string.Empty; ;
            id = string.Empty;
            created = DateTime.Now;
            conversationId = string.Empty;
        }
    }
}
