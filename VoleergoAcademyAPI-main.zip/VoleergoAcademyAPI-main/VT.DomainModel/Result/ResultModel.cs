﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VT.DomainModel.Result
{
    public class ResultModel
    {
        [JsonProperty("result_id")]
        public int Result { get; set; }

        [JsonProperty("mark")]
        public string Mark { get; set; }




        public ResultModel()
        {
            Result = 0;
            Mark=string.Empty;

        }
        

    }


   
}
