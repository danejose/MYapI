﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace VT.DomainModel.StudentProfile
{
    public class StudentProfile
    {
        [JsonProperty("FK_User")]
        public int FK_User { get; set; }
        [JsonProperty("FK_DISTRICT")]
        public int FK_DISTRICT { get; set; }
        [JsonProperty("FK_State")]
        public int FK_State { get; set; }
        [JsonProperty("FirstName")]
        public string FirstName { get; set; }
        [JsonProperty("LastName")]
        public string LastName { get; set; }
        [JsonProperty("FK_ProfileImage")]
        public int FK_ProfileImage { get; set; }
        [JsonProperty("Email")]
        public string Email { get; set; }
        [JsonProperty("PhoneNo")]
        public string PhoneNo { get; set; }

        [JsonProperty("Address1")]
        public string Address1 { get; set; }
        [JsonProperty("Address2")]
        public string Address2 { get; set; }
        [JsonProperty("Address3")]
        public string Address3 { get; set; }
        [JsonProperty("AddressType")]
        public string AddressType { get; set; }
        [JsonProperty("PIN")]
        public string PIN { get; set; }


        public StudentProfile()
        {
            FK_User = 0;
            FK_DISTRICT = 0;
            FK_State = 0;   
            FirstName = string.Empty; 
            FK_ProfileImage= 0;
            LastName = string.Empty;
            Email = string.Empty;
            PhoneNo = string.Empty;
            Address1 = string.Empty;
            Address2 = string.Empty;
            Address3 = string.Empty;
            PIN = string.Empty;
            AddressType= string.Empty;


        }

    }
}
