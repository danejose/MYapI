﻿using System;
using Newtonsoft.Json;

namespace VT.DomainModel.Auth
{
    public class ChangePasswordModel : BaseModel
    {
        [JsonProperty("fk_User")]
        public long Fk_User { get; set; }

        [JsonProperty("oldPassword")]
        public string OldPassword { get; set; }

        [JsonProperty("newPassword")]
        public string NewPassword { get; set; }

        public ChangePasswordModel()
        {
            OldPassword = string.Empty;
            NewPassword = string.Empty;
        }
    }
}
