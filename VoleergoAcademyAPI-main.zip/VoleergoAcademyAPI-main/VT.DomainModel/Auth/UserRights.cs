﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VT.DomainModel.Auth
{
    public class UserRights
    {

        [JsonProperty("fk_User")]
        public Int64 Fk_User { get; set; }

        [JsonProperty("fk_MenuGroup")]
        public Int64 FK_MenuGroup { get; set; }

        [JsonProperty("fk_Role")]
        public Int64 FK_Role { get; set; }

        public UserRights()
        {
            Fk_User = 0;
            FK_MenuGroup = 0;
            FK_Role = 0;
        }
    }
}
