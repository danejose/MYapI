﻿
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;

namespace VT.DomainModel.Auth
{
   public class LoginModel : HttpResponses
    {
        [JsonProperty("ID_Users")]
        public int ID_Users { get; set; }

        [JsonProperty("FK_Course")]
        public int FK_Course { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        [JsonProperty("LastName")]
        public string LastName { get; set; }

        [JsonProperty("MobileNumber")]
        public string MobileNumber { get; set; }

        [JsonProperty("Password")]
        public string Password { get; set; }

        [JsonProperty("PasswordStr")]
        public string PasswordStr { get; set; }

        [JsonProperty("IsMobile")]
        public int IsMobile { get; set; }

        public LoginModel() {
            ID_Users = 0;
            FK_Course = 0;
            FirstName = string.Empty;
            LastName = string.Empty;
            MobileNumber = string.Empty;
            Password = string.Empty;
            PasswordStr = string.Empty;
            IsMobile = 0;
        }
    }
}
