﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using VLG.DomainModel.Auth;

namespace VT.DomainModel.Auth
{
    public class RegisterModel : BaseModel
    {
        [JsonProperty("ID_Users")]
        public int ID_Users { get; set; }

        [JsonProperty("FK_Course")]
        public int FK_Course {  get; set; }

        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        [JsonProperty("LastName")]
        public string LastName { get; set; }

        [JsonProperty("Dob")]
        public DateTime? Dob { get; set; }   

        [JsonProperty("Email")]
        public string Email { get; set; }
         
        [JsonProperty("MobileNumber")]
        public string MobileNumber { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("ResumeID")]
        public int ResumeID { get; set; }

        [JsonProperty("Address")]
        public string Address {  get; set; }

        [JsonProperty("Password")]
        public string Password { get; set; }

        [JsonProperty("PasswordStr")]
        public string PasswordStr { get; set; }

        [JsonProperty("IsMobile")]
        public int IsMobile { get; set; }

        [JsonProperty("Date")]
        public DateOnly Date {  get; set; }

        [JsonProperty("AddressType")]
        public string AddressType {  get; set; }

        public RegisterModel()
        {
            ID_Users = 0;
            FK_Course = 0;
            FirstName = string.Empty;
            LastName = string.Empty;
            Dob = DateTime.Now;
            Email = string.Empty;
            MobileNumber = string.Empty;
            Description = string.Empty;
            Address = string.Empty;
            Password = string.Empty;
            PasswordStr = string.Empty;
            AddressType = string.Empty;
            ResumeID = 0;
            IsMobile = 0;

        }
    }
}
