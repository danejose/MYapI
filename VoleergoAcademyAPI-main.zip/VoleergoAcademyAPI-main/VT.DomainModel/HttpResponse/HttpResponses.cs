﻿ using System;
using System.Collections.Generic;
using System.Text;
using VT.DomainModel;

namespace VLG.DomainModel
{
    public class HttpResponses 
    {       
        public string? ResponseCode { get; set; }      
        public bool ResponseStatus { get; set; }      
        public object? Response { get; set; }       
        public string? ResponseType { get; set; }      
        public string? ResponseMessage { get; set; }
        public Int64 ResponseID { get; set; }
        public Int64 Mark { get; set; }


        public HttpResponses()
        {
            ResponseCode = "0";
            ResponseStatus = false;
            ResponseType = string.Empty;
            ResponseMessage = string.Empty;
            ResponseID = 0;

        }
    }
}
