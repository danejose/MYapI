﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VLG.DomainModel.Auth
{
    public  class UserImageResponse: HttpResponses
    {
        public string? ImageUrl { get; set; }

        public UserImageResponse()
        {
            ImageUrl= string.Empty;
        }
    }
}
