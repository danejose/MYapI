﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VLG.DomainModel
{
    public class HttpLoginResponse: HttpResponses
    {
        [JsonProperty("ID_Users")]
        public int ID_Users { get; set; }

        [JsonProperty("FK_Course")]
        public int FK_Course { get; set; }

        [JsonProperty("Email")]
        public string Email { get; set; }

        [JsonProperty("FirstName")]
        public string FirstName { get; set; }

        [JsonProperty("LastName")]
        public string LastName { get; set; }

        [JsonProperty("MobileNumber")]
        public string MobileNumber { get; set; }

        [JsonProperty("Password")]
        public string Password { get; set; }

        [JsonProperty("PasswordStr")]
        public string PasswordStr { get; set; }

        [JsonProperty("IsMobile")]
        public int IsMobile { get; set; }

        [JsonProperty("Menuname")]
        public string Menuname { get; set; }

        public string? Token { get;set; }
        public DateTime? Expiration { get; set; }
        public string? Sid { get; set; }

        public HttpLoginResponse()
        {          
            Token = string.Empty;
            Expiration = DateTime.Now;
            Sid = string.Empty;
            ID_Users = 0;
            FK_Course = 0;
            FirstName = string.Empty;
            LastName = string.Empty;
            MobileNumber = string.Empty;
            Password = string.Empty;
            PasswordStr = string.Empty;
            Menuname = string.Empty;
            IsMobile = 0;

        }
    }
}
