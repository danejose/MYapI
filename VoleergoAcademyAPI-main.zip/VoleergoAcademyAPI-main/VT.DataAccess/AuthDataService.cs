﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel.Auth;
using Voleergo.Utility;
using VT.DomainModel;
using VT.Common;
using Amazon.Runtime;
using VLG.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Common;
using ZstdSharp.Unsafe;
using VT.DomainModel.Question;
using Microsoft.Extensions.Options;

namespace VT.DataAccess
{
    public class AuthDataService 
    {
        private readonly GenSettings _settings;

        public AuthDataService(GenSettings settings)
        {
            _settings = settings;
        }

        public  UserImageResponse UserUploadUpdate(UserUploadModel userUpload)
        {
            UserImageResponse result = new UserImageResponse();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@ImgName", DbType = DbType.String, Value = userUpload.ImageName},
                new SqlParameter {ParameterName = "@ImgType", DbType = DbType.String, Value = userUpload.ImageType},
                new SqlParameter {ParameterName = "@ImgUrl" , DbType = DbType.String,Value = userUpload.ImageURL},
                new SqlParameter {ParameterName = "@CreatedBy", DbType = DbType.String, Value = userUpload.CreatedBy},
                new SqlParameter {ParameterName = "@ID_UserUpload" , DbType = DbType.Int64, Value = userUpload.ID_UserImages},
               
            };

            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateUserUpload, parameters))
                {
                    while (dataReader.Read())
                    {
                        
                        result.ResponseID = Convert.ToInt32(dataReader["ResponseID"]);
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ImageUrl = Convert.ToString(dataReader["ImageUrl"]);
                    }
                }
            
            }catch(Exception ex)
            {
                return result;
            }
            return result;
        }

        public List<QuestionModel> QuestionSelect(Int64? id_Course, Int64? level)
        {

            QuestionModel result = new QuestionModel();
            List<QuestionModel> questionList = new List<QuestionModel>();
            SqlHelper sqlHelper = new SqlHelper(_settings);

            List<SqlParameter> parameters = new List<SqlParameter>()
    {
        new SqlParameter { ParameterName = "@FK_Course", DbType = DbType.Int64, Value = id_Course ?? (object)DBNull.Value },
        new SqlParameter { ParameterName = "@FK_InterviewLevel", DbType = DbType.Int64, Value = level ?? (object)DBNull.Value }
    };

            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectRandomInterviewQuestions, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new QuestionModel();
                        result.Id_Question = Convert.ToInt16(dataReader["ID_MockInterview"]);
                        result.Question = Convert.ToString(dataReader["Question"]);
                        result.Option1 = Convert.ToString(dataReader["Option1"]);
                        result.Option2 = Convert.ToString(dataReader["Option2"]);
                        result.Option3 = Convert.ToString(dataReader["Option3"]);
                        result.Option4 = Convert.ToString(dataReader["Option4"]);
                        result.Answer = Convert.ToInt16(dataReader["Answer"]);




                        questionList.Add(result);
                    }
                }
                return questionList;
            }
            catch (Exception ex)
            {
                return questionList;
            }
        }

        public HttpResponses RegisterUserUpdate(RegisterModel user)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@ID_User", DbType = DbType.String, Value = user.ID_Users},
                new SqlParameter { ParameterName = "@FK_Course", DbType = DbType.Int64, Value = user.FK_Course},
                new SqlParameter { ParameterName = "@FirstName" , DbType = DbType.String,Value = user.FirstName},
                new SqlParameter { ParameterName = "@LastName" , DbType = DbType.String,Value = user.LastName},
                new SqlParameter { ParameterName = "@Dob" , DbType = DbType.DateTime,Value = user.Dob},
                new SqlParameter { ParameterName = "@Email" , DbType = DbType.String,Value = user.Email},
                new SqlParameter { ParameterName = "@PhoneNo" , DbType = DbType.String,Value = user.MobileNumber},
                new SqlParameter { ParameterName = "@Description",DbType = DbType.String,Value = user.Description },
                //new SqlParameter { ParameterName = "@Address",DbType = DbType.String, Value = user.Address},
                new SqlParameter { ParameterName = "@CreatedBy", DbType = DbType.String, Value = user.CreatedBy},
                new SqlParameter { ParameterName = "@Password",DbType = DbType.String,Value = user.Password},
                new SqlParameter { ParameterName = "@AddressType",DbType=DbType.String,Value = user.AddressType}

            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UserRegistrationUpdate, parameters))
                {
                    while (dataReader.Read())
                    {
                        result.ResponseID = Convert.ToInt32(dataReader["ResponseID"]);
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseStatus = Convert.ToBoolean(dataReader["ResponseStatus"]);
                        
                    }
                }
            }catch(Exception ex)
            {
                return result;
            }
            return result;
        }

        public HttpResponses ChangePassword(ChangePasswordModel changePasswordModel)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int64, Value = changePasswordModel.Fk_User },
                new SqlParameter { ParameterName = "@OldPassword", DbType = DbType.String, Value = changePasswordModel.OldPassword },
                new SqlParameter { ParameterName = "@NewPassword", DbType = DbType.String, Value = changePasswordModel.NewPassword }

                };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_ChangePassword, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseCode = Convert.ToInt32(dataReader["ResponseCode"]).ToString();
                        //   result.ResponseStatus = Convert.ToInt16(dataReader["ResponseStatus"]);
                    }
                }
            }
            catch (Exception ex)
            {

                return result;
            }
            return result;
        }
        public HttpResponses UserRights(UserRights changePasswordModel)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int64, Value = changePasswordModel.Fk_User },
                new SqlParameter { ParameterName = "@FK_MenuGroup", DbType = DbType.Int64, Value = changePasswordModel.Fk_User },
                new SqlParameter { ParameterName = "@FK_Role", DbType = DbType.Int64, Value = changePasswordModel.Fk_User },


                };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateUserRights, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseCode = Convert.ToInt32(dataReader["ResponseCode"]).ToString();
                    }
                }
            }
            catch (Exception ex)
            {

                return result;
            }
            return result;
        }
        public HttpResponses UpdatesQuestion(QuestionModel options)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
                 {
              new SqlParameter { ParameterName = "@FK_MockInterView ", DbType = DbType.Int64, Value = options.Id_Question},
              new SqlParameter { ParameterName = "@FK_Course ", DbType = DbType.Int64, Value = options.Id_Course},
              new SqlParameter { ParameterName = "@fk_User", DbType = DbType.Int64, Value = options.Id_User},
              new SqlParameter { ParameterName = "@AttemptedAnswer", DbType = DbType.Int64, Value = options.AttemptedAnswer},
              new SqlParameter { ParameterName = "@FK_InterviewLevel ", DbType = DbType.Int64, Value = options.Level},

              new SqlParameter { ParameterName = "@ID_MockResult", DbType = DbType.Int64, Value = 0},
};
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateMockInterviewResult, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseID = Convert.ToInt32(dataReader["ResponseID"]);
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);



                    }
                }
            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }



        public HttpLoginResponse LoginUser(LoginModel loginuser)
        {           
            UserUploadModel model = new UserUploadModel();
            HttpLoginResponse logindata = new HttpLoginResponse();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@UserCode",DbType = DbType.String,Value = loginuser.Email},
                new SqlParameter {ParameterName = "@Password",DbType = DbType.String,Value = loginuser.Password},
                new SqlParameter {ParameterName = "@MAC" ,DbType = DbType.String,Value = model.MACAddress},
                new SqlParameter {ParameterName = "@IP",DbType = DbType.String,Value = model.IPAddress},
                new SqlParameter {ParameterName = "@IsMobile", DbType = DbType.Int16, Value = loginuser.IsMobile}
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_ValidateLogin, parameters))
                {
                    while(dataReader.Read())
                    {
                        logindata = new HttpLoginResponse();
                        logindata.ID_Users = Convert.ToInt16(dataReader["ID_User"]);
                        logindata.Email = Convert.ToString(dataReader["Email"]);
                        logindata.Password = Convert.ToString(dataReader["Password"]);
                        logindata.FirstName = Convert.ToString(dataReader["FirstName"]);
                        logindata.LastName = Convert.ToString(dataReader["LastName"]);
                        logindata.MobileNumber = Convert.ToString(dataReader["PhoneNo"]);
                        logindata.ResponseID = Convert.ToInt16(dataReader["ResponseID"]);
                        logindata.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        logindata.ResponseStatus = Convert.ToBoolean(dataReader["ResponseStatus"]);
                        logindata.Menuname = Convert.ToString(dataReader["MenuName"]);
                       
                    }
                }
            
            }catch(Exception ex)
            {
                return logindata;
            }

            return logindata;
        }

        public HttpResponses Forgotpassword(RegisterModel user)
        {
            HttpResponses response = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@Email",DbType = DbType.String,Value = user.Email},
                new SqlParameter {ParameterName = "@password",DbType = DbType.String,Value = user.Password},
               
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_updatepassword, parameters))
                {
                    while(dataReader.Read())
                    {
                        response = new HttpResponses();
                        response.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        response.ResponseID = Convert.ToInt16(dataReader["ResponseID"]);
                    }
                }
            }
            catch(Exception ex)
            {
                return response;
            }
            return response;
        }
 


    }
}
