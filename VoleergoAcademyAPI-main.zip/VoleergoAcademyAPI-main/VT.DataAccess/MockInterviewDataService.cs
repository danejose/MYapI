﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using Voleergo.Utility;
using VT.Common;
using VT.DomainModel;
using VT.DomainModel.HR;
using VT.DomainModel.Master;
using VT.DomainModel.MockInterview;
using VT.DomainModel.Question;
using VT.DomainModel.StudentHistory;

namespace VT.DataAccess
{
    public class MockInterviewDataService
    {

        private readonly GenSettings _settings;

        public MockInterviewDataService(GenSettings settings)
        {
            _settings = settings;
        }


        public List<DashboardSection> DashBoardSection(Int64 fk_User)
        {
            DashboardSection result = new DashboardSection();
            List<DashboardSection> studentList = new List<DashboardSection>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                    new SqlParameter { ParameterName = "@FK_User  ", DbType = DbType.Int64, Value = fk_User},
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectMockInterviewDashboard, parameters))
                {
                    while (dataReader.Read())

                    {
                        result = new DashboardSection();
                        result.ID_InterviewCourse = Convert.ToInt64(dataReader["ID_InterviewCourse"]);
                        result.NoOfExamAttended = Convert.ToInt64(dataReader["NoOfExamAttended"]);
                        result.TotalMarkPercentage = Convert.ToDecimal(dataReader["TotalMarkPercentage"]);
                        result.LastMarkPercentage = Convert.ToDecimal(dataReader["LastMarkPercentage"]);
                        result.CourseName = Convert.ToString(dataReader["CourseName"]);
                        result.IsUpward = Convert.ToBoolean(dataReader["IsUpward"]);


                        studentList.Add(result);
                    }
                }
                return studentList;

            }
            catch (Exception ex)
            {
                return studentList;
            }
        }


        public List<DashboardSection1> DashBoardSection1(Int64 fk_User)
        {
            DashboardSection1 result = new DashboardSection1();
            List<DashboardSection1> studentList = new List<DashboardSection1>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@FK_User  ", DbType = DbType.Int64, Value = fk_User},


            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectMockInterviewQuestion, parameters))
                {
                    while (dataReader.Read())

                    {
                        result = new DashboardSection1();

                        result.ID_InterviewCourse = Convert.ToInt64(dataReader["ID_InterviewCourse"]);
                        result.CourseName = Convert.ToString(dataReader["CourseName"]);
                        result.InterviewLevel = Convert.ToString(dataReader["InterviewLevel"]);
                        result.MarkObtained = Convert.ToInt64(dataReader["MarkObtained"]);
                        result.PercenOfMarks = Convert.ToDecimal(dataReader["PercenOfMarks"]);
                        result.ID_MockInterviewQuestion = Convert.ToInt64(dataReader["ID_MockInterviewQuestion"]);
                        result.CompletedTime = Convert.ToInt64(dataReader["CompletedTime"]);
                        result.ModifiedDate = Convert.ToDateTime(dataReader["ModifiedDate"]);
                        studentList.Add(result);
                    }
                }
                return studentList;

            }
                catch (Exception ex)
            {
                return studentList;
            }
        }

        public List<DashboardSectionReviewList> DashBoardSectionReview(Int64 id_MockInterviewQuestion)
        {
            DashboardSectionReviewList result = new DashboardSectionReviewList();
            List<DashboardSectionReviewList> studentList = new List<DashboardSectionReviewList>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@ID_MockInterviewQuestion  ", DbType = DbType.Int64, Value = id_MockInterviewQuestion},


            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectMockInterviewQuestionsDetails, parameters))
                {
                    while (dataReader.Read())

                    {
                        result = new DashboardSectionReviewList();

                        result.ID_MockInterviewQuestionDetails = Convert.ToInt64(dataReader["ID_MockInterviewQuestionDetails"]);
                        result.CorrectAnswer = Convert.ToString(dataReader["CorrectAnswer"]);
                        result.AttendedAnswer = Convert.ToString(dataReader["AttendedAnswer"]);
                        result.ID_InterviewQuestions = Convert.ToInt64(dataReader["ID_InterviewQuestions"]);
                        result.Question = Convert.ToString(dataReader["Question"]);
                        result.Option1 = Convert.ToString(dataReader["Option1"]);
                        result.Option2 = Convert.ToString(dataReader["Option2"]);
                        result.Option3 = Convert.ToString(dataReader["Option3"]);
                        result.Option4 = Convert.ToString(dataReader["Option4"]);

                        studentList.Add(result);
                    }
                }
                return studentList;

            }
            catch (Exception ex)
            {
                return studentList;
            }
        }
        public List<MockInterviewModel> SelectMockInterviewQuestion(Int64? fk_InterviewCourse,Int64? fk_InterviewLevel,Int64? fk_User)
        {
            MockInterviewModel result = new MockInterviewModel();
            List<MockInterviewModel> mockList = new List<MockInterviewModel>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
              new SqlParameter { ParameterName = "@FK_InterviewCourse", DbType = DbType.Int64, Value = fk_InterviewCourse},
              new SqlParameter { ParameterName = "@FK_InterviewLevel ", DbType = DbType.Int64, Value = fk_InterviewLevel},
              new SqlParameter { ParameterName = "@FK_User  ", DbType = DbType.Int64, Value = fk_User},
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectMockRandomInterviewQuestions, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new MockInterviewModel();
                        result.ID_MockInterviewQuestionDetails = Convert.ToInt32(dataReader["id_MockInterviewQuestionDetails"]);
                        result.FK_MockInterviewQuestion = Convert.ToInt64(dataReader["fk_MockInterviewQuestion"]);
                        result.FK_InterviewQuestions = Convert.ToInt64(dataReader["fk_InterviewQuestions"]);
                        result.Question = Convert.ToString(dataReader["Question"]);
                        result.Option1 = Convert.ToString(dataReader["Option1"]);
                        result.Option2 = Convert.ToString(dataReader["Option2"]);
                        result.Option3 = Convert.ToString(dataReader["Option3"]);
                        result.Option4 = Convert.ToString(dataReader["Option4"]);

                        mockList.Add(result);
                    }
                }
                return mockList;

            }
            catch (Exception ex)
            {
                return mockList;
            }
        }
        public HttpResponses UpdateMockInterviewQuestionDetails(MockInterviewModel mockInterviewModel)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
       
                new SqlParameter{ ParameterName= "@ID_MockInterviewQuestionDetails ", DbType= DbType.Int64, Value= mockInterviewModel.ID_MockInterviewQuestionDetails },
                new SqlParameter{ ParameterName= "@FK_MockInterviewQuestion  ", DbType= DbType.Int64, Value= mockInterviewModel.FK_MockInterviewQuestion  },
                new SqlParameter{ ParameterName= "@FK_InterviewQuestions   ", DbType= DbType.Int64, Value= mockInterviewModel.FK_InterviewQuestions   },
                new SqlParameter{ ParameterName= "@AttendAnswer", DbType= DbType.Int64, Value= mockInterviewModel.AttendAnswer},
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateMockInterviewQuestionDetails, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseStatus = Convert.ToBoolean(dataReader["ResponseStatus"]);
                        result.ResponseID = Convert.ToInt64(dataReader["ResponseID"]);
                        result.Mark = Convert.ToInt64(dataReader["Mark"]);

                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }

        public HttpResponses UpdateMockInterviewQuestion(MockInterviewModel mockInterviewModel)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {

                new SqlParameter{ ParameterName= "@FK_MockInterviewQuestion", DbType= DbType.Int64, Value= mockInterviewModel.FK_MockInterviewQuestion  },
                new SqlParameter{ ParameterName= "@CompletedTime", DbType= DbType.Int64, Value= mockInterviewModel.CompletedTime},
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateMockInterviewQuestion, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseStatus = Convert.ToBoolean(dataReader["ResponseStatus"]);
                        result.ResponseID = Convert.ToInt64(dataReader["ResponseID"]);
                        result.Mark = Convert.ToInt64(dataReader["Mark"]);
                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }

    }
}
