﻿using Amazon.Runtime.Documents;
using EllipticCurve.Utils;
using MongoDB.Bson;
using MongoDB.Driver;
using NLog.Filters;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Xml.Linq;
using VT.Common;
using VT.DomainModel.Common;

namespace VT.DataAccess
{
    public class MongoDBHelper
    {
        public static string _mongConnectionString;
        public static string _dbName;
        public MongoDBHelper(string mongConnectionString,string dbName)
        {
            _mongConnectionString = mongConnectionString;
            _dbName = dbName;
        }
        //public ResponseStatus TicketReplynUpdate(TicketReply ticketReply)
        //{
        //    try
        //    {
        //        TicketReplySub ticketReplySub = new TicketReplySub();
        //        ticketReplySub.ID_Ticket = ticketReply.ID_Ticket;
        //        ticketReplySub.TicketDescription = DataConverter.ConvertToByteArray(ticketReply.TicketDescriptionStr);
        //        ticketReplySub.CreatedBy = ticketReply.CreatedBy;
        //        ticketReplySub.ModifiedBy = ticketReply.ModifiedBy;
        //        ticketReplySub.CreateDate = DateTime.Now.ToString("dd/MM/yyy hh:MM:ss");

        //        MongoClient dbClient = new MongoClient(_mongConnectionString);
        //        var database = dbClient.GetDatabase(_dbName);
        //        var collection = database.GetCollection<TicketReply>("ticketreply");
        //        var filtera = Builders<TicketReply>.Filter.Eq(x => x.ID_Ticket, ticketReply.ID_Ticket);
        //        var results = collection.Find(filtera).ToList();
        //        if (results.Count > 0)
        //        {
        //            results[0].TicketDescription.Add(ticketReplySub);
        //            var updates = Builders<TicketReply>.Update.Set("TicketDescription", results[0].TicketDescription);
        //            var resul = collection.FindOneAndUpdate(filtera, updates).ToJson();

        //        }
        //        else
        //        {
        //            ticketReply.TicketDescription.Add(ticketReplySub);
        //            collection.InsertOne(ticketReply);
        //        }
        //    }
        //    catch(Exception ex)
        //    {
        //        return new ResponseStatus { ReturnCode = "-1", ReturnMessage = "Insertion Failed", TrackingNumber = "-1" };
        //    }
        //    return new ResponseStatus { ReturnCode = "1", ReturnMessage = "Sucessfully Added",TrackingNumber = "1" };
        //}
        //public List<TicketReply> TicketReplynSelect(TicketReply ticketReply)
        //{
        //    List<TicketReply> ticketReplyList = new List<TicketReply>();           
        //    MongoClient dbClient = new MongoClient(_mongConnectionString);
        //    var database = dbClient.GetDatabase(_dbName);
        //    var collection = database.GetCollection<TicketReply>("ticketreply");
        //    var filtera = Builders<TicketReply>.Filter.Eq(x => x.ID_Ticket, ticketReply.ID_Ticket);
        //    var results = collection.Find(filtera).ToList();
        //    if (results.Count > 0)
        //    {
        //        foreach (var item in results[0].TicketDescription)
        //        {
        //            ticketReplyList.Add(new TicketReply
        //            {
        //                TicketDescriptionStr = DataConverter.ConvertToString(item.TicketDescription),
        //                CreatedBy = item.CreatedBy,
        //                ModifiedBy = item.ModifiedBy,
        //                CreateDate = item.CreateDate
        //            }); 
        //        }
        //    }
        //    return ticketReplyList;
        //}

    }
}
