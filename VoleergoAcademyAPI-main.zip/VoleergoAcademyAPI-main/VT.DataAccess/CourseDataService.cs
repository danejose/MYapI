﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel.Auth;
using Voleergo.Utility;
using VT.DomainModel;
using VT.Common;
using Amazon.Runtime;
using VLG.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Common;
using ZstdSharp.Unsafe;
using VT.DomainModel.HR;
using VT.DomainModel.Question;
using VT.DomainModel.Result;
using Microsoft.AspNetCore.Http.HttpResults;

namespace VT.DataAccess
{
    public class CourseDataService
    {
        private readonly GenSettings _settings;

        public CourseDataService(GenSettings settings)
        {
            _settings = settings;
        }

       
        public List<QuestionModel> QuestionSelect(Int64? id_Course, Int64? level)
        {
            List<QuestionModel> questionList = new List<QuestionModel>();
            SqlHelper sqlHelper = new SqlHelper(_settings);

            List<SqlParameter> parameters = new List<SqlParameter>()
    {
        new SqlParameter { ParameterName = "@FK_Course", DbType = DbType.Int64, Value = id_Course ?? (object)DBNull.Value },
        new SqlParameter { ParameterName = "@FK_InterviewLevel", DbType = DbType.Int64, Value = level ?? (object)DBNull.Value }
    };

            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectRandomInterviewQuestions, parameters))
                {
                    while (dataReader.Read())
                    {
                        QuestionModel result = new QuestionModel
                        {
                            Id_Question = Convert.ToInt16(dataReader["ID_MockInterview"]),
                            Question = Convert.ToString(dataReader["Question"]),
                            Option1 = Convert.ToString(dataReader["Option1"]),
                            Option2 = Convert.ToString(dataReader["Option2"]),
                            Option3 = Convert.ToString(dataReader["Option3"]),
                            Option4 = Convert.ToString(dataReader["Option4"]),
                            Answer = Convert.ToInt16(dataReader["Answer"])
                        };

                        questionList.Add(result);
                    }
                }
                return questionList;
            }
            catch (Exception ex)
            {
                return questionList;
            }
        }


        //public List<ResultModel> ResultSelect(ResultModel resultModel)
        //{
        //    List<ResultModel> userResult = new List<ResultModel>();
        //    SqlHelper sqlHelper = new SqlHelper(_settings);

        //    List<SqlParameter> parameters = new List<SqlParameter>()
        //    {

        //            new SqlParameter {ParameterName = "@FK_Result", DbType = DbType.Int64, Value = resultModel.Result}
        //    };
        //    try
        //    {
        //        using(IDataReader dataReader=sqlHelper.ExecuteReader(Procedures.ResultSelect, parameters))
        //        {
        //            while (dataReader.Read())
        //            {
        //                resultModel = new ResultModel();
        //                resultModel.Mark = Convert.ToString(dataReader["FK_Mark"]);


        //            }
        //            userResult.Add(resultModel);
        //        }

        //    }
        //    catch(Exception ex)
        //    {
        //        return userResult;
        //    }
        //    return userResult;

        //}


        public HttpResponses UpdatesQuestion(QuestionModel options)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
                 {


              new SqlParameter { ParameterName = "@FK_InterviewQuestions", DbType = DbType.Int64, Value = options.Id_Question},
            //  new SqlParameter { ParameterName = "@FK_Course", DbType = DbType.Int64, Value = options.Id_Course},

              new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int64, Value = options.Id_User},


              new SqlParameter { ParameterName = "@AttendedAnswer", DbType = DbType.Int64, Value = options.AttemptedAnswer},
              new SqlParameter { ParameterName = "@Attended", DbType = DbType.Int64, Value = options.Enabled},

            //  new SqlParameter { ParameterName = "@FK_InterviewLevel ", DbType = DbType.Int64, Value = options.Level},

              new SqlParameter { ParameterName = "@ID_MockInterviewQuestionDetails", DbType = DbType.Int64, Value = 0},
};
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateMockInterviewQuestionDetails, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseID = Convert.ToInt32(dataReader["ResponseID"]);
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);



                    }
                }
            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }


    }
}
