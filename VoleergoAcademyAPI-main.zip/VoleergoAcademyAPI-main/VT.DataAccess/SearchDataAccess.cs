﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Voleergo.Utility;
using VT.DomainModel;
using VT.DomainModel.SearchUser;
using VT.Common;

namespace VT.DataAccess
{
    public class SearchDataAccess
    {
        private readonly GenSettings _settings;

        public SearchDataAccess(GenSettings settings)
        {
            _settings = settings;
        }

        public List<SearchUserModel> UserSearch(SearchUserModel searchUser)
        {
            List<SearchUserModel> Usermodel = new List<SearchUserModel>();
            SearchUserModel model = new SearchUserModel();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@ID_User",DbType=DbType.Int64,Value=searchUser.ID_User},
                new SqlParameter {ParameterName = "@Name",DbType = DbType.String,Value = searchUser.Name},
                new SqlParameter {ParameterName = "@Email",DbType = DbType.String,Value = searchUser.Email},
                new SqlParameter {ParameterName = "@PhoneNo" ,DbType = DbType.String,Value = searchUser.Phone},
                new SqlParameter {ParameterName = "@CourseName",DbType = DbType.String,Value = searchUser.Course},
                
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UserSearchByHR, parameters))
                {
                    while (dataReader.Read())
                    {
                        model = new SearchUserModel();
                        model.ID_User = Convert.ToString(dataReader["ID_User"]);
                        model.Name = Convert.ToString(dataReader["FirstName"]);
                        model.Email = Convert.ToString(dataReader["Email"]);
                        model.Phone = Convert.ToString(dataReader["PhoneNo"]);
                        model.Course = Convert.ToString(dataReader["CourseName"]);
                        Usermodel.Add(model);

                    }
                }
            }catch (Exception ex)
            {
                return Usermodel;
            }
            return Usermodel;
        }
    }
}
