﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using Voleergo.Utility;
using VT.Common;
using VT.DomainModel;
using VT.DomainModel.StudentHistory;
using VT.DomainModel.StudentProfile;
using VT.DomainModel.StudentAdditionalDetails;
using VT.DomainModel.Master;
using VT.DomainModel.Question;
using VT.DomainModel.HR;
using System.Text.RegularExpressions;
using SendGrid;
using System.Buffers;
using System.IO;
using VT.DomainModel.MockInterview;

namespace VT.DataAccess
{
    public class HrDataService
    {
        private readonly GenSettings _settings;

        public HrDataService(GenSettings settings)
        {
            _settings = settings;
        }

        public List<CourseRegisteredStudent> SelectCourseRegisteredUser(Int64 fk_User)
        {
            CourseRegisteredStudent result = new CourseRegisteredStudent();
            List<CourseRegisteredStudent> studentList = new List<CourseRegisteredStudent>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
              new SqlParameter { ParameterName = "@FK_User", DbType = DbType.String, Value = fk_User},
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectUserCourseHistory, parameters))
                {
                    while (dataReader.Read())
                    {
                        result.LastName = Convert.ToString(dataReader["LastName"]);
                        result.FirstName = Convert.ToString(dataReader["FirstName"]);
                        result.Email = Convert.ToString(dataReader["Email"]);
                        result.PhoneNo = Convert.ToString(dataReader["PhoneNo"]);
                        result.Address1 = Convert.ToString(dataReader["Address1"]);
                        result.Address2 = Convert.ToString(dataReader["Address2"]);
                        result.Address3 = Convert.ToString(dataReader["Address3"]);
                        result.AddressType = Convert.ToString(dataReader["AddressType"]);
                        result.PIN = Convert.ToInt32(dataReader["PIN"]);
                        result.ID_Number = Convert.ToString(dataReader["ID_Number"]);
                        result.FK_User = Convert.ToInt32(dataReader["FK_User"]);
                        result.FK_Course = Convert.ToInt32(dataReader["FK_Course"]);
                        result.FK_IdType = Convert.ToInt32(dataReader["FK_IdType"]);
                        result.FK_BloodGroup = Convert.ToInt32(dataReader["FK_BloodGroup"]);
                        result.FK_BatchType = Convert.ToInt32(dataReader["FK_BatchType"]);
                        result.FK_CourseType = Convert.ToInt32(dataReader["FK_CourseType"]);
                        result.FK_Gender =Convert.ToInt32(dataReader["FK_Gender"]) ;
                        result.FK_State =Convert.ToInt32(dataReader["FK_State"]);
                        result.FK_District = Convert.ToInt32(dataReader["FK_District"]);
                        result.EmergencyContact = Convert.ToInt64(dataReader["EmergencyContact"]);
                        result.Dob = Convert.ToDateTime(dataReader["Dob"]) ;
                        result.FK_UserRegistration = Convert.ToInt32(dataReader["FK_UserRegistration"]) ;
                        result.RegId = Convert.ToString(dataReader["RegId"]);
                        result.ModifiedDate =Convert.ToDateTime(dataReader["ModifiedDate"]);
                        result.ModifiedBy = Convert.ToInt32(dataReader["ModifiedBy"]);

                        studentList.Add(result);
                    }
                }
                return studentList;

            }
            catch (Exception ex)
            {
                return studentList;
            }            
        }
        public List<UserRegisteredCourse> SelectRegisteredCourse(Int64? id_userRegistration, string? searchValue, string? fetchType)
        {
            UserRegisteredCourse result = new UserRegisteredCourse();
            List<UserRegisteredCourse> studentList = new List<UserRegisteredCourse>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
              new SqlParameter { ParameterName = "@ID_UserRegistration", DbType = DbType.Int64, Value = id_userRegistration==null?0:id_userRegistration},
              new SqlParameter { ParameterName = "@SearchValue", DbType = DbType.String, Value = searchValue==null?"":searchValue},
              new SqlParameter { ParameterName = "@FetchType", DbType = DbType.String, Value = fetchType==null?"":fetchType}


            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectUserCourseRegistration, parameters))
                {
                    while (dataReader.Read())

                    {
                        result = new UserRegisteredCourse();
                        result.RegId = Convert.ToString(dataReader["RegId"]);
                        result.ID_UserRegistration = Convert.ToInt32(dataReader["ID_UserRegistration"]);
                        result.UniqueID = Convert.ToString(dataReader["UniqueID"]);
                        result.JoinDate = Convert.ToDateTime(dataReader["JoinDate"]);
                        result.FK_BatchType = Convert.ToInt32(dataReader["FK_BatchType"]);
                        result.FK_CourseType = Convert.ToInt32(dataReader["FK_CourseType"]);
                        result.FK_User = Convert.ToInt32(dataReader["FK_User"]);
                        result.FK_State = Convert.ToInt32(dataReader["FK_State"]);
                        result.FK_DISTRICT = Convert.ToInt32(dataReader["FK_DISTRICT"]);
                        result.Name = Convert.ToString(dataReader["Name"]);
                        result.Email = Convert.ToString(dataReader["Email"]);
                        result.PhoneNo = Convert.ToString(dataReader["PhoneNo"]);
                        result.CourseName = Convert.ToString(dataReader["CourseName"]);
                        result.ID_Course = Convert.ToInt64(dataReader["ID_Course"]);
                        result.Address1 = Convert.ToString(dataReader["Address1"]);
                        result.Address2 = Convert.ToString(dataReader["Address2"]);
                        result.Address3 = Convert.ToString(dataReader["Address3"]);
                        result.PIN = Convert.ToString(dataReader["PIN"]);
                        result.PAddress1 = Convert.ToString(dataReader["PAddress1"]);
                        result.PAddress2 = Convert.ToString(dataReader["PAddress2"]);
                        result.PAddress3 = Convert.ToString(dataReader["PAddress3"]);
                        result.PPIN = Convert.ToString(dataReader["PPIN"]);
                        result.EmergencyContact = Convert.ToString(dataReader["EmergencyContact"]);
                        result.FK_BloodGroup = Convert.ToInt32(dataReader["FK_BloodGroup"]);
                        result.FK_IdProof = Convert.ToInt32(dataReader["FK_IdProof"]);
                        result.ID_Number = Convert.ToString(dataReader["ID_Number"]);
                        result.FK_Gender = Convert.ToInt32(dataReader["FK_Gender"]);



                        studentList.Add(result);
                    }
                }
                return studentList;

            }
            catch (Exception ex)
            {
                return studentList;
            }
        }

      
        public HttpResponses UpdateCourseRegistration(CourseRegisteredStudent courseRegisteredStudent)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {                
                new SqlParameter{ ParameterName= "@JoinDate", DbType= DbType.DateTime, Value= courseRegisteredStudent.JoinDate },
                new SqlParameter{ ParameterName= "@Address1", DbType= DbType.String, Value= courseRegisteredStudent.Address1 },
                new SqlParameter{ ParameterName= "@Address2", DbType= DbType.String, Value= courseRegisteredStudent.Address2 },
                new SqlParameter{ ParameterName= "@Address3", DbType= DbType.String, Value= courseRegisteredStudent.Address3 },
                new SqlParameter{ ParameterName= "@AddressType", DbType= DbType.String, Value= courseRegisteredStudent.AddressType },
                new SqlParameter{ ParameterName= "@PIN", DbType= DbType.Int32, Value= courseRegisteredStudent.PIN },
                new SqlParameter{ ParameterName= "@ID_Number", DbType= DbType.String, Value= courseRegisteredStudent.ID_Number },
                new SqlParameter{ ParameterName= "@FK_User", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_User },
                new SqlParameter{ ParameterName= "@FK_Course", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_Course },
                new SqlParameter{ ParameterName= "@FK_IdType", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_IdType },
                new SqlParameter{ ParameterName= "@FK_BloodGroup", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_BloodGroup },
                new SqlParameter{ ParameterName= "@FK_BatchType", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_BatchType },
                new SqlParameter{ ParameterName= "@FK_CourseType", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_CourseType },
                new SqlParameter{ ParameterName= "@FK_Gender", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_Gender },
                new SqlParameter{ ParameterName= "@FK_State", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_State },
                new SqlParameter{ ParameterName= "@FK_DISTRICT", DbType= DbType.Int32, Value= courseRegisteredStudent.FK_District },
                new SqlParameter{ ParameterName= "@EmergencyContact", DbType= DbType.String, Value= courseRegisteredStudent.EmergencyContact },
                new SqlParameter{ ParameterName= "@Dob", DbType= DbType.DateTime, Value= courseRegisteredStudent.Dob },
                new SqlParameter{ ParameterName= "@ID_UserRegistration", DbType= DbType.Int32, Value= courseRegisteredStudent.ID_UserRegistration },
                new SqlParameter{ ParameterName= "@ModifiedBy", DbType= DbType.Int32, Value= courseRegisteredStudent.ModifiedBy },
                new SqlParameter{ ParameterName= "@PAddress1", DbType= DbType.String, Value= courseRegisteredStudent.PAddress1 },
                new SqlParameter{ ParameterName= "@PAddress2", DbType= DbType.String, Value= courseRegisteredStudent.PAddress2 },
                new SqlParameter{ ParameterName= "@PAddress3", DbType= DbType.String, Value= courseRegisteredStudent.PAddress3 },
                new SqlParameter{ ParameterName= "@PPIN", DbType= DbType.Int32, Value= courseRegisteredStudent.PPIN }

            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateUserCourseRegistration, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseStatus = Convert.ToBoolean(dataReader["ResponseStatus"]);                       
                        result.ResponseID = Convert.ToInt64(dataReader["ResponseID"]);                     
                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }

        public List<RegisteredUser> SelectRegisteredUser(Int64? id_user, string? searchValue, string? fetchType)
        {
            RegisteredUser result = new RegisteredUser();
            List<RegisteredUser> studentList = new List<RegisteredUser>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
              new SqlParameter { ParameterName = "@SearchValue", DbType = DbType.String, Value = searchValue==null?"":searchValue},
              new SqlParameter { ParameterName = "@ID_User", DbType = DbType.Int64, Value = id_user==null?0:id_user},
              new SqlParameter { ParameterName = "@fetchType", DbType = DbType.String, Value = fetchType==null?"":fetchType}             
             
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectRegisterdUser, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new RegisteredUser();
                        result.ID_User = Convert.ToInt64(dataReader["ID_User"]);
                        result.ResumeUrl = Convert.ToString(dataReader["ResumeUrl"]);
                        result.Date = Convert.ToString(dataReader["Date"]);
                        result.CourseName = Convert.ToString(dataReader["CourseName"]);
                        result.Description = Convert.ToString(dataReader["Description"]);
                        result.Dob = Convert.ToDateTime(dataReader["Dob"]);
                        result.Email = Convert.ToString(dataReader["Email"]);
                        result.FirstName = Convert.ToString(dataReader["FirstName"]); 
                        result.Name = Convert.ToString(dataReader["Name"]);
                        result.PhoneNo = Convert.ToString(dataReader["PhoneNo"]); 
                        result.FirstName = Convert.ToString(dataReader["FirstName"]);
                        result.LastName = Convert.ToString(dataReader["LastName"]);
                        studentList.Add(result);
                    }
                }
                return studentList;

            }
            catch (Exception ex)
            {
                return studentList;
            }
        }
        public List<UserRegistered> UserRegistered(Int64? id_userregistration)
        {
            UserRegistered result = new UserRegistered();
            List<UserRegistered> studentList = new List<UserRegistered>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
              new SqlParameter { ParameterName = "@ID_UserRegistration", DbType = DbType.Int64, Value = id_userregistration==null?0:id_userregistration},
             

            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectRegisteredUserCourseDetail, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new UserRegistered();
                        result.FK_User = Convert.ToInt64(dataReader["FK_User"]);
                        result.JoinDate = Convert.ToDateTime(dataReader["JoinDate"]);
                        result.BatchTypeName = Convert.ToString(dataReader["BatchTypeName"]);
                        result.Course = Convert.ToString(dataReader["Course"]);
                        result.CourseTypeName = Convert.ToString(dataReader["CourseTypeName"]);
                        result.State = Convert.ToString(dataReader["State"]);
                        result.District = Convert.ToString(dataReader["District"]);
                        result.BloodGroup = Convert.ToString(dataReader["BloodGroup"]);
                        result.IDProofName = Convert.ToString(dataReader["IDProofName"]);
                        result.Gender = Convert.ToString(dataReader["Gender"]);
                        result.Address1 = Convert.ToString(dataReader["Address1"]);
                        result.Address2 = Convert.ToString(dataReader["Address2"]);
                        result.Address3 = Convert.ToString(dataReader["Address3"]);
                        result.PIN = Convert.ToString(dataReader["PIN"]);
                        result.EmergencyContact = Convert.ToString(dataReader["EmergencyContact"]);
                        result.PAddress1 = Convert.ToString(dataReader["PAddress1"]);
                        result.PAddress2 = Convert.ToString(dataReader["PAddress2"]);
                        result.PAddress3 = Convert.ToString(dataReader["PAddress3"]);
                        result.PPIN = Convert.ToString(dataReader["PPIN"]);
                        result.ID_Number = Convert.ToString(dataReader["ID_Number"]);
                        result.ModifiedDate = Convert.ToDateTime(dataReader["ModifiedDate"]);
                        result.FK_BatchType = Convert.ToInt64(dataReader["FK_BatchType"]);
                        result.FK_CourseType = Convert.ToInt64(dataReader["FK_CourseType"]);
                        result.FK_Course = Convert.ToInt64(dataReader["FK_Course"]);
                        result.FK_District = Convert.ToInt64(dataReader["FK_District"]);
                        result.FK_State = Convert.ToInt64(dataReader["FK_State"]);
                        result.FK_BloodGroup = Convert.ToInt64(dataReader["FK_BloodGroup"]);
                        result.FK_Gender = Convert.ToInt64(dataReader["FK_Gender"]);
                        result.FK_IdProof = Convert.ToInt64(dataReader["FK_IdProof"]);

                        studentList.Add(result);
                    }
                }
                return studentList;

            }
            catch (Exception ex)
            {
                return studentList;
            }
        }

        /// <summary>
        /// To fetch all entered details of user
        /// </summary>
        /// <param name="fk_User"></param>
        /// <returns></returns>

        public List<DetailsCourseUser> DetailsCourseUser(Int64 fk_User)
        {
            DetailsCourseUser result = new DetailsCourseUser();
            List<DetailsCourseUser> userDetails = new List<DetailsCourseUser>();
            SqlHelper sqlHelper = new SqlHelper(_settings);

            List<SqlParameter> parameters = new List<SqlParameter>()
              {
                 new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int64, Value = fk_User }
               };


            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectLatestUserCourseDetails, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new DetailsCourseUser();
                        result.Name = Convert.ToString(dataReader["Name"]);
                        result.Email = Convert.ToString(dataReader["Email"]);
                        result.FK_DISTRICT = Convert.ToInt64(dataReader["FK_DISTRICT"]);
                        result.FK_Course = Convert.ToInt64(dataReader["FK_Course"]);
                        result.FK_Gender = Convert.ToInt64(dataReader["FK_Gender"]);
                        result.FK_State = Convert.ToInt64(dataReader["FK_State"]);
                        result.FK_BatchType = Convert.ToInt64(dataReader["FK_BatchType"]);
                        result.FK_CourseType = Convert.ToInt64(dataReader["FK_CourseType"]);
                        result.FK_IdProof = Convert.ToInt64(dataReader["FK_IdProof"]);
                        result.FK_BloodGroup = Convert.ToInt64(dataReader["FK_BloodGroup"]);
                        result.PhoneNo = Convert.ToString(dataReader["PhoneNo"]);
                        result.Dob = Convert.ToDateTime(dataReader["DOB"]);
                        result.Description = Convert.ToString(dataReader["Description"]);
                        result.District = Convert.ToString(dataReader["District"]);
                        result.State = Convert.ToString(dataReader["State"]);
                        result.Course = Convert.ToString(dataReader["CourseName"]);
                        result.BatchType = Convert.ToString(dataReader["BatchTypeName"]);
                        result.CourseType = Convert.ToString(dataReader["CourseTypeName"]);
                        result.ExpecJoinDate = Convert.ToDateTime(dataReader["ExpecJoinDate"]);
                        result.RegID = Convert.ToString(dataReader["RegID"]);
                        
                        userDetails.Add(result); 
                    }
                }
                return userDetails; 
            }
            catch (Exception ex)
            {
                return userDetails; 
            }
        }

        public HttpResponses UpdateRegisteredUser(RegisteredStudent registeredStudent)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@Address1", DbType = DbType.String, Value = registeredStudent.Address1 },
                new SqlParameter { ParameterName = "@Address2", DbType = DbType.String, Value = registeredStudent.Address2 },
                new SqlParameter { ParameterName = "@Address3", DbType = DbType.String, Value = registeredStudent.Address3 },
                new SqlParameter { ParameterName = "@AddressType", DbType = DbType.String, Value = registeredStudent.AddressType },
                new SqlParameter { ParameterName = "@PIN", DbType = DbType.Int32, Value = registeredStudent.PIN },
                new SqlParameter { ParameterName = "@EmergencyContact", DbType = DbType.Int64, Value = registeredStudent.EmergencyContact },
                new SqlParameter { ParameterName = "@FK_State", DbType = DbType.Int32, Value = registeredStudent.FK_State },
                new SqlParameter { ParameterName = "@FK_DISTRICT", DbType = DbType.Int32, Value = registeredStudent.FK_District },
                new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int32, Value = registeredStudent.FK_User },
                new SqlParameter { ParameterName = "@ExpecJoinDate", DbType = DbType.DateTime, Value = registeredStudent.ExpecJoinDate }, 
                new SqlParameter { ParameterName = "@FK_BatchType", DbType = DbType.Int32, Value = registeredStudent.FK_BatchType },
                new SqlParameter { ParameterName = "@FK_CourseType", DbType = DbType.Int32, Value = registeredStudent.FK_CourseType },
                new SqlParameter { ParameterName = "@FK_Course", DbType = DbType.Int32, Value = registeredStudent.FK_Course },
                new SqlParameter { ParameterName = "@ModifiedBy", DbType = DbType.Int32, Value = registeredStudent.ModifiedBy },


            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateUserCourseRegistration, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);                        
                        result.ResponseID = Convert.ToInt64(dataReader["ResponseID"]);
                        
                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }


        public HttpResponses UpdateUserCourseDetails(UserCourseDetails userCourseDetails)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@FK_Course", DbType = DbType.Int64, Value = userCourseDetails.FK_Course },
                new SqlParameter { ParameterName = "@FK_State", DbType = DbType.Int64, Value = userCourseDetails.FK_State },
                new SqlParameter { ParameterName = "@FK_DISTRICT", DbType = DbType.Int64, Value = userCourseDetails.FK_District },
                new SqlParameter { ParameterName = "@FK_BatchType", DbType = DbType.Int64, Value = userCourseDetails.FK_BatchType },
                new SqlParameter { ParameterName = "@FK_CourseType", DbType = DbType.Int64, Value = userCourseDetails.FK_CourseType },
                new SqlParameter { ParameterName = "@ExpecJoinDate", DbType = DbType.DateTime, Value = userCourseDetails.ExpectedJoinDate },
                new SqlParameter { ParameterName = "@Description", DbType = DbType.String, Value = userCourseDetails.Description },
                new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int64, Value = userCourseDetails.ID_User },
                new SqlParameter { ParameterName = "@ModifiedBy", DbType = DbType.Int64, Value = userCourseDetails.ModifiedBy },
                new SqlParameter { ParameterName = "@TransDate", DbType = DbType.DateTime, Value = userCourseDetails.TransDate },
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateUserCourseDetails, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseCode = Convert.ToString(dataReader["ResponseCode"]);
                    }
                }
            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }
        public HttpResponses StudentProfile(StudentProfile studentProfile)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter { ParameterName = "@FK_User", DbType = DbType.Int64, Value = studentProfile.FK_User },
                new SqlParameter { ParameterName = "@FirstName", DbType = DbType.String, Value = studentProfile.FirstName },
                new SqlParameter { ParameterName = "@FK_ProfileImage", DbType = DbType.String, Value = studentProfile.FK_ProfileImage },
                new SqlParameter { ParameterName = "@LastName", DbType = DbType.String, Value = studentProfile.LastName },
                new SqlParameter { ParameterName = "@PhoneNo", DbType = DbType.String, Value = studentProfile.PhoneNo },
                new SqlParameter { ParameterName = "@Email", DbType = DbType.String, Value = studentProfile.Email },
                new SqlParameter { ParameterName = "@Address1", DbType = DbType.String, Value = studentProfile.Address1 },
                new SqlParameter { ParameterName = "@Address2", DbType = DbType.String, Value = studentProfile.Address2 },
                new SqlParameter { ParameterName = "@Address3", DbType = DbType.String, Value = studentProfile.Address3 },
                new SqlParameter { ParameterName = "@PIN", DbType = DbType.Int64, Value = studentProfile.PIN },
                new SqlParameter { ParameterName = "@FK_State", DbType = DbType.Int64, Value = studentProfile.FK_State },
                new SqlParameter { ParameterName = "@FK_DISTRICT", DbType = DbType.Int64, Value = studentProfile.FK_DISTRICT },
                new SqlParameter { ParameterName = "@AddressType", DbType = DbType.String, Value = studentProfile.AddressType },


                    };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateUserProfile, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                        result.ResponseID = Convert.ToInt64(dataReader["ResponseID"]);
                     //   result.ResponseStatus = Convert.ToInt16(dataReader["ResponseStatus"]);
                    }
                }
            }
            catch (Exception ex)
            {

                return result;
            }
            return result;
        }
        public List<UserCourseDetails> SelectCourseDetails(Int64 fk_user, Int64 id_UserCourseDetails)
        {
            UserCourseDetails result = new UserCourseDetails();
            List<UserCourseDetails> courseUserList = new List<UserCourseDetails>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {              
              new SqlParameter { ParameterName = "@id_UserCourseDetails", DbType = DbType.Int64, Value = id_UserCourseDetails == null?0:id_UserCourseDetails},
              new SqlParameter { ParameterName = "@fk_user", DbType = DbType.Int64, Value = fk_user == null?0:fk_user}
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectUserCourseDetails, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new UserCourseDetails();
                        result.ID_UserCourseDetails = Convert.ToInt64(dataReader["ID_UserCourseDetails"]);
                        result.ID_User = Convert.ToInt64(dataReader["FK_User"]);
                        result.ExpectedJoinDate = Convert.ToDateTime(dataReader["ExpecJoinDate"]);
                        result.BatchTypeName = Convert.ToString(dataReader["BatchTypeName"]);
                        result.CourseType = Convert.ToString(dataReader["CourseTypeName"]);
                        result.State = Convert.ToString(dataReader["State"]);
                        result.District = Convert.ToString(dataReader["DISTRICT"]);
                        result.CourseName = Convert.ToString(dataReader["CourseName"]);
                        result.Description = Convert.ToString(dataReader["Description"]);

                        result.FK_BatchType = Convert.ToInt64(dataReader["FK_BatchType"]);
                        result.FK_CourseType = Convert.ToInt64(dataReader["FK_CourseType"]);
                        result.FK_State = Convert.ToInt64(dataReader["FK_State"]);
                        result.FK_District = Convert.ToInt64(dataReader["FK_DISTRICT"]);
                        //result.FK_CourseType = Convert.ToInt64(dataReader["FK_Course"]);
                        result.FK_Course = Convert.ToInt64(dataReader["FK_Course"]);
                        result.TransDateStr = Convert.ToString(dataReader["TransDateStr"]);
                        result.TransDate = Convert.ToDateTime(dataReader["TransDate"]);
                        courseUserList.Add(result);
                    }
                }
                return courseUserList;

            }
            catch (Exception ex)
            {
                return courseUserList;
            }
        }

    }
};
