﻿/*----------------------------------- Data Access Repository Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : 
Author     : Jinesh Kumar C
Copyright  : 
Created on : 04/03/2017
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			By			
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

04/03/2017	Jinesh Kumar C			

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/


using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Voleergo.Utility;
using VT.Common;
using VT.DomainModel;


namespace VT.DataAccess
{
    public class CommonDataService
    {
        private readonly GenSettings _settings;
        public CommonDataService(GenSettings settings)
        {
            _settings = settings;
        }
      
        
        public List<SelectListItem> BindDropDwonFromView(string viewName)
        {
            List<SelectListItem> resultSub = new List<SelectListItem>();
            List<SelectListItem> result = new List<SelectListItem>();
            DatabaseFactory.SetDatabaseProviderFactory(new DatabaseProviderFactory(), false);
            Database db = EnterpriseExtentions.GetDatabase(_settings.ConnectionStrings);
            string sqlCommand = String.Format("SELECT ID,NAME FROM {0}", viewName);
            DbCommand dbCommand = db.GetSqlStringCommand(sqlCommand);           
            try
            {
                using (IDataReader dataReader = db.ExecuteReader(dbCommand))
                {
                    while (dataReader.Read())
                    { 
                        result.Add(new SelectListItem { Value = Convert.ToString(dataReader["ID"].ToString()), Text = Convert.ToString(dataReader["Name"].ToString())});
                    }
                }
                return result;
            }
            catch (SqlException e)
            {
              //  UpdateErrorLog(e, (byte)UserAction.Select, users.EnteredBy, users.IPAddress, users.FK_Client, users.FK_ClientBranch);
                throw e;
            }
        }
        public List<SelectListItem> BindDropDown(string tableName,string fields,string condition)
        {
            
            List<SelectListItem> result = new List<SelectListItem>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>() { };
            string sqlCommand = String.Format("SELECT {1} FROM {0} WHERE 0 = 0 AND {2}", tableName, fields, condition);           
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteStringReader(sqlCommand,parameters))
                {
                    while (dataReader.Read())
                    {
                        result.Add(new SelectListItem { Value = Convert.ToString(dataReader["ID"].ToString()), Text = Convert.ToString(dataReader["Name"].ToString()) });
                    }
                }
                return result;
            }
            catch (SqlException e)
            {
                //  UpdateErrorLog(e, (byte)UserAction.Select, users.EnteredBy, users.IPAddress, users.FK_Client, users.FK_ClientBranch);
                throw e;
            }
        }

        public string GetData(string tableName, string fields, string condition)
        {
            String result = string.Empty;
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {

            };
            string sqlCommand = String.Format("SELECT {1} FROM {0} WHERE 0 = 0 AND {2} FOR JSON AUTO", tableName, fields, condition);        
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(sqlCommand, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = result + Convert.ToString(dataReader[0]);
                    }
                }
                return result;
            }
            catch (SqlException e)
            {
                //  UpdateErrorLog(e, (byte)UserAction.Select, users.EnteredBy, users.IPAddress, users.FK_Client, users.FK_ClientBranch);
                throw e;
            }
        }

        public string DropDownData() { 
            String result = string.Empty;
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {

            };
            try {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectDropDownData, parameters))
                {
                    while (dataReader.Read())
                    {
                       result = Convert.ToString(dataReader["Data"]);
                    }
                }
            } catch (Exception ex)
            {
                return result;
            }
            return result;
        }

        #region Common
        public void UpdateErrorLog(SqlException e, byte action, Int64 EnteredBy, string IPAddress, Int64 FK_Client, Int64 FK_ClientBranch)
        {
            ErrorModel error = new ErrorModel();
            error.ErrDetails = e.Message.ToString();
            error.Action = action;
            error.EnteredBy = EnteredBy;
            error.Module = "SEC";
            error.IPAddress = IPAddress;
            error.FK_Client = FK_Client;
            error.FK_ClientBranch = FK_ClientBranch;
           // LogDataService.UpdateErrorLog(error);
        }
        #endregion Common 
    }
}
