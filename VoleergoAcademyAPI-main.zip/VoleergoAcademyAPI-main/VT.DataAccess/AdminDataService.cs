﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using Voleergo.Utility;
using VT.Common;
using VT.DomainModel;
using VT.DomainModel.Master;
using VT.DomainModel.Question;
using VT.DomainModel.StudentHistory;

namespace VT.DataAccess
{
    public class AdminDataService
    {

        private readonly GenSettings _settings;

        public AdminDataService(GenSettings settings)
        {
            _settings = settings;
        }

        public HttpResponses UpdateQuestion(QuestionModel options)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
                 {
              new SqlParameter { ParameterName = "@ID_InterviewQuestions", DbType = DbType.Int64, Value = options.Id_MockInterview},

              new SqlParameter { ParameterName = "@FK_InterviewCourse", DbType = DbType.Int64, Value = options.Id_Course},
              new SqlParameter { ParameterName = "@FK_InterviewLevel", DbType = DbType.Int64, Value = options.Level},
              new SqlParameter { ParameterName = "@Question", DbType = DbType.String, Value = options.Question},
              new SqlParameter { ParameterName = "@Option1", DbType = DbType.String, Value = options.Option1},
              new SqlParameter { ParameterName = "@Option2", DbType = DbType.String, Value = options.Option2},
              new SqlParameter { ParameterName = "@Option3", DbType = DbType.String, Value = options.Option3},
              new SqlParameter { ParameterName = "@Option4", DbType = DbType.String, Value = options.Option4},
              new SqlParameter { ParameterName = "@Answer", DbType = DbType.Int64, Value = options.Answer},
              new SqlParameter { ParameterName = "@CreatedBy", DbType = DbType.Int64, Value = options.CreatedBy},




            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_UpdateInterviewQuestions, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseID = Convert.ToInt32(dataReader["ResponseID"]);
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);



                    }
                }
            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }

        public HttpResponses DeleteQuestion(int questionId)
        {
            HttpResponses result = new HttpResponses();
            SqlHelper sqlHelper = new SqlHelper(_settings);

            // Correct way to add the parameter to the list
            List<SqlParameter> parameters = new List<SqlParameter>
    {
        new SqlParameter { ParameterName = "@ID_InterViewQuestions", DbType = DbType.Int64, Value = questionId }
    };

            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_DeleteMockInterviewQuestion, parameters))
                {
                    while (dataReader.Read())
                    {
                        result = new HttpResponses();
                        result.ResponseID = Convert.ToInt32(dataReader["ResponseID"]);
                        result.ResponseMessage = Convert.ToString(dataReader["ResponseMessage"]);
                    }
                }
            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }






        public List<QuestionModel> SelectQuestion(QuestionModel question)
        {
            List<QuestionModel> result = new List<QuestionModel>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@FK_InterviewCourse", DbType = DbType.Int64, Value = question.Id_Course}
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectInterviewQuestion, parameters))
                {
                    while (dataReader.Read())
                    {
                        question = new QuestionModel();
                        question.Id_Course = Convert.ToInt32(dataReader["FK_Course"]);
                        question.Level = Convert.ToInt32(dataReader["level"]);


                        //question.Level = Convert.ToString(dataReader["InterviewLevel"]);
                        question.CourseName = Convert.ToString(dataReader["CourseName"]);

                        question.Id_MockInterview = Convert.ToInt32(dataReader["ID_InterviewQuestions"]);

                        question.Question = Convert.ToString(dataReader["Question"]);
                        question.Option1 = Convert.ToString(dataReader["Option1"]);
                        question.Option2 = Convert.ToString(dataReader["Option2"]);
                        question.Option3 = Convert.ToString(dataReader["Option3"]);
                        question.Option4 = Convert.ToString(dataReader["Option4"]);
                        question.Answer = Convert.ToInt32(dataReader["Answer"]);
                        question.LevelName = Convert.ToString(dataReader["InterviewLevel"]);
                        question.CourseName = Convert.ToString(dataReader["CourseName"]);    
                        result.Add(question);
                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }

        public string UserMenus(int fk_user)
        {
            String result = string.Empty;
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@FK_user", DbType = DbType.Int64, Value = fk_user}
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_MenuName, parameters))
                {
                    while(dataReader.Read())
                    {
                        result = Convert.ToString(dataReader["Data"]);
                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }
    }
}
