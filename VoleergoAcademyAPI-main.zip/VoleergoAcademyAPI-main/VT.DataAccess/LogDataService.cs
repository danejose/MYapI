﻿/*----------------------------------- Data Access Repository Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : 
Author     : Jinesh Kumar C
Copyright  : 
Created on : 05/03/2017
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			By			
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

05/03/2017	Jinesh Kumar C			

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using Microsoft.Extensions.Options;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using VT.Common;
using VT.DomainModel;

namespace VT.DataAccess
{
    public class LogDataService
    {
        public void UpdateErrorLog(ErrorModel errorlog, IOptions<GenSettings> _settings)
        {
            DatabaseFactory.SetDatabaseProviderFactory(new DatabaseProviderFactory(), false);
            Database db = EnterpriseExtentions.GetDatabase(_settings.Value.ConnectionStrings);
            string sqlCommand = Procedures.SP_ErrorLogUpdate;
            DbCommand dbCommand = db.GetStoredProcCommand(sqlCommand);
            dbCommand.CommandTimeout = 0;

            db.AddInParameter(dbCommand, "@Action", DbType.Int64, errorlog.Action);
            db.AddInParameter(dbCommand, "@Module", DbType.String, errorlog.Module);
            db.AddInParameter(dbCommand, "@ErrDetails", DbType.String, errorlog.ErrDetails);
            db.AddInParameter(dbCommand, "@ErrMessage", DbType.String, errorlog.ErrMessage);
            db.AddInParameter(dbCommand, "@EnteredBy", DbType.Int64, errorlog.EnteredBy);
            db.AddInParameter(dbCommand, "@IPAddress", DbType.String, errorlog.IPAddress);
            db.AddInParameter(dbCommand, "@FK_Client", DbType.Int64, errorlog.FK_Client);
            db.AddInParameter(dbCommand, "@FK_ClientBranch", DbType.Int64, errorlog.FK_ClientBranch);
            try
            {
                db.ExecuteNonQuery(dbCommand);
            }
            catch (SqlException e)
            {
                
            }
        }
    }
}
