﻿using System.Data.Common;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VT.DomainModel;
using VT.DomainModel.Master;
using Voleergo.Utility;
using System.Data;
using VT.Common;

namespace VT.DataAccess
{
    
    public class MasterFileDataService
    {
        private readonly GenSettings _settings;

        public MasterFileDataService(GenSettings settings)
        {
            _settings = settings;
        }

        public List<CourseDomainModel> Courses(CourseDomainModel course)
        {
            List<CourseDomainModel> result = new List<CourseDomainModel>();
            SqlHelper sqlHelper = new SqlHelper(_settings);
            List<SqlParameter> parameters = new List<SqlParameter>()
            {
                new SqlParameter {ParameterName = "@ID_Course", DbType = DbType.Int64, Value = course.ID}
            };
            try
            {
                using (IDataReader dataReader = sqlHelper.ExecuteReader(Procedures.SP_SelectCourse, parameters))
                {
                    while(dataReader.Read())
                    {
                        course = new CourseDomainModel();
                        course.ID = Convert.ToInt32(dataReader["ID_Course"]);
                        course.ImageSrc = Convert.ToString(dataReader["ImgSrc"]);
                        course.Title = Convert.ToString(dataReader["CourseName"]);
                        course.Link = Convert.ToString(dataReader["Href"]);
                        course.Description = Convert.ToString(dataReader["Description"]);
                        course.Href = Convert.ToString(dataReader["Href1"]);
                        result.Add(course);
                    }
                }

            }
            catch (Exception ex)
            {
                return result;
            }
            return result;
        }
    }
}
