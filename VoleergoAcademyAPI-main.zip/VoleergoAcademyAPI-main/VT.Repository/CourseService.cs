﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using Voleergo.Utility;

using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Question;
using VT.DomainModel.Result;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class CourseService : ICourseService
    {
        public GenSettings Settings { get; set; }


        //public List<ResultModel> result(ResultModel resultModel)
        //{
        //    CourseDataService courseDataService = new CourseDataService(Settings);
        //    return courseDataService.ResultSelect(resultModel);
        //}
        public List<QuestionModel> QuestionSelect(int id_Course, int level)
        {
            CourseDataService courseDataService = new CourseDataService(Settings);
            return courseDataService.QuestionSelect(id_Course, level);

        }
        public HttpResponses Questionsl(QuestionModel options)
        {

            CourseDataService courseDataService = new CourseDataService(Settings);
            return courseDataService.UpdatesQuestion(options);

        }
    
    }
}
