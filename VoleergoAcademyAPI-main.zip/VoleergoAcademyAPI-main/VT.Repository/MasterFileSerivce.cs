﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.Master;
using VT.ServiceInterfaces;
namespace VT.Repository
{
    public class MasterFileSerivce : IMasterService
    {
        public GenSettings Settings { get; set; }

        public List<CourseDomainModel> CourseGet(CourseDomainModel course)
        {
            MasterFileDataService service = new MasterFileDataService(Settings);
            return service.Courses(course);
        }
    }
}
