﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.SearchUser;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class SearchUserService : ISearchUser
    {
        public GenSettings Settings { get; set; }

        public List<SearchUserModel> Search(SearchUserModel search)
        {
            SearchDataAccess searchService = new SearchDataAccess(Settings);
            return searchService.UserSearch(search);
        }
        
    }
}
