﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using Voleergo.Utility;

using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Question;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class AuthService : IAuthService
    {
        public GenSettings Settings { get; set; }


        public HttpResponses Questionsl(QuestionModel options)
        {

            AuthDataService authDataService = new AuthDataService(Settings);
            return authDataService.UpdatesQuestion(options);

        }
        public HttpResponses UserRights(UserRights userRights)
        {
            AuthDataService authDataService = new AuthDataService(Settings);
            return authDataService.UserRights(userRights);  // Pass UserRights here
        }

        public UserImageResponse UserUploadUpdate(UserUploadModel userUpload)
        {
            AuthDataService authDataService = new AuthDataService(Settings);
            return authDataService.UserUploadUpdate(userUpload);
        }
        public HttpResponses RegisterUser(RegisterModel user)
        {
            AuthDataService authDataService = new AuthDataService(Settings);
            if(user.ID_Users == 0)
            {
                user.PasswordStr = user.Password;
                user.PasswordStr = GeneratePassword();
                MD5 md5Hash = MD5.Create();
                user.Password = Cryptography.GetMd5Hash(md5Hash,user.PasswordStr ?? "");
                
            }
            return authDataService.RegisterUserUpdate(user);
        }


        
        public string GeneratePassword()
        {
            int length = 8;
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+";
            var random = new Random();
            string password = new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
            return password;
        }
        public List<QuestionModel> QuestionSelect(int? id_Course, int? level)
        {
            AuthDataService authDataService = new AuthDataService(Settings);
            return authDataService.QuestionSelect(id_Course,level);

        }
    public HttpResponses ChangePassword(ChangePasswordModel changePasswordModel)
{
    AuthDataService authDataService = new AuthDataService(Settings);
    
    if (!string.IsNullOrEmpty(changePasswordModel.OldPassword))
    {
        MD5 md5Hash = MD5.Create();
        changePasswordModel.OldPassword = Cryptography.GetMd5Hash(md5Hash, changePasswordModel.OldPassword);
    }
    
    if (!string.IsNullOrEmpty(changePasswordModel.NewPassword))
    {
        MD5 md5Hash = MD5.Create();
        changePasswordModel.NewPassword = Cryptography.GetMd5Hash(md5Hash, changePasswordModel.NewPassword);
    }
    
    return authDataService.ChangePassword(changePasswordModel);
}


        public HttpLoginResponse LoginUser(LoginModel loginuser)
        {
            AuthDataService authDataService = new AuthDataService(Settings);
            if (loginuser.ID_Users == 0)
            {
                loginuser.PasswordStr = loginuser.Password;                
                MD5 md5Hash = MD5.Create();
                loginuser.Password = Cryptography.GetMd5Hash(md5Hash, loginuser.PasswordStr ?? "");

            }
            return authDataService.LoginUser(loginuser);
        }

        public HttpResponses forgotPasssword(RegisterModel model)
        {
            AuthDataService authDataService = new AuthDataService(Settings);
            if (model != null)
            {

                model.PasswordStr = GeneratePassword();
                MD5 md5Hash = MD5.Create();
                model.Password = Cryptography.GetMd5Hash(md5Hash, model.PasswordStr ?? "");
            }
            return authDataService.Forgotpassword(model);
        }
     
    }
}
