﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.Master;
using VT.DomainModel.Question;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class AdminService: IAdminService
    {
        public GenSettings Settings { get; set; }
        public HttpResponses UpdateQuestion(QuestionModel options)
        {
            AdminDataService AdminDataService = new AdminDataService(Settings);
            return AdminDataService.UpdateQuestion(options);
        }

        public List<QuestionModel> SelectQuestion(QuestionModel question)
        {
            AdminDataService AdminDataService = new AdminDataService(Settings);
            return AdminDataService.SelectQuestion(question);
        }

        public HttpResponses DeleteQuestion(int questionId)
        {

            AdminDataService AdminDataService = new AdminDataService(Settings);
            return AdminDataService.DeleteQuestion(questionId);

        }
        public string UserMenus(int fk_user)
        {
            AdminDataService AdminDataService = new AdminDataService(Settings);
            return AdminDataService.UserMenus(fk_user);
        }
    }
}
