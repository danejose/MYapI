﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using Voleergo.Utility;

using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.HR;
using VT.DomainModel.MockInterview;
using VT.DomainModel.Question;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class MockInterviewService : IMockInterview
    {
        public GenSettings Settings { get; set; }

      
        public List<MockInterviewModel> SelectMockInterviewQuestion(Int64 fk_InterviewCourse, Int64 fk_InterviewLevel,Int64 fk_User)
        {
            MockInterviewDataService mockInterviewDataService = new MockInterviewDataService(Settings);
            return mockInterviewDataService.SelectMockInterviewQuestion(fk_InterviewCourse, fk_InterviewLevel, fk_User);
        }
        public List<DashboardSection1> DashBoardSection1(Int64 fk_User)
        {
            MockInterviewDataService mockInterviewDataService = new MockInterviewDataService(Settings);
            return mockInterviewDataService.DashBoardSection1(fk_User);
        }
        public List<DashboardSectionReviewList> DashBoardSectionReview(Int64 id_MockInterviewQuestion)
        {
            MockInterviewDataService mockInterviewDataService = new MockInterviewDataService(Settings);
            return mockInterviewDataService.DashBoardSectionReview(id_MockInterviewQuestion);
        }

        public HttpResponses UpdateMockInterviewQuestionDetails(MockInterviewModel mockInterviewModel)
        {
            MockInterviewDataService mockInterviewDataService = new MockInterviewDataService(Settings);
            return mockInterviewDataService.UpdateMockInterviewQuestionDetails(mockInterviewModel);
        }
        public HttpResponses UpdateMockInterviewQuestion(MockInterviewModel mockInterviewModel)
        {
            MockInterviewDataService mockInterviewDataService = new MockInterviewDataService(Settings);
            return mockInterviewDataService.UpdateMockInterviewQuestion(mockInterviewModel);
        }
        public List<DashboardSection> DashBoardSection(Int64 fk_User)
        {
            MockInterviewDataService mockInterviewDataService = new MockInterviewDataService(Settings);
            return mockInterviewDataService.DashBoardSection(fk_User);
        }

    }
}
