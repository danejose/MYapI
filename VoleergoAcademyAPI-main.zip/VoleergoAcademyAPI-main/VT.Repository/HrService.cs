﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VT.DataAccess;
using VT.DomainModel;
using VT.DomainModel.StudentHistory;
using VT.DomainModel.StudentProfile;
using VT.DomainModel.StudentAdditionalDetails;

using VT.ServiceInterfaces;
using VT.DomainModel.HR;
using VT.DomainModel.MockInterview;
using System.Buffers;

namespace VT.Repository
{
    public class HrService :IHrService
    {
        public GenSettings Settings { get; set; }

        public HttpResponses UpdateCourseRegistration(CourseRegisteredStudent courseRegisteredStudent)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.UpdateCourseRegistration(courseRegisteredStudent);
        }
     
        public List<CourseRegisteredStudent> SelectCourseRegisteredUser(Int64 fk_User,string? searchValue, string? fetchType)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.SelectCourseRegisteredUser(fk_User);

        }
        public HttpResponses UpdateRegisteredUser(RegisteredStudent registeredStudent)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.UpdateRegisteredUser(registeredStudent);
        }

        public List<RegisteredUser> SelectRegisteredUser(Int64? id_user, string? searchValue, string? fetchType)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.SelectRegisteredUser(id_user, searchValue, fetchType);
        }

 
        public List<UserRegisteredCourse> SelectRegisteredCourse(Int64? id_userRegistration, string? searchValue, string? fetchType)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.SelectRegisteredCourse(id_userRegistration, searchValue, fetchType);
        }
        public List<UserRegistered> UserRegistered(Int64? id_userregistration)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.UserRegistered(id_userregistration);
        }
        public HttpResponses StudentProfile(StudentProfile studentProfile)
        {
            HrDataService hrDataaccess = new HrDataService(Settings);   
            return hrDataaccess.StudentProfile(studentProfile);
        }

        public HttpResponses UpdateUserCourseDetails(UserCourseDetails userCourseDetails)
        {
            HrDataService hrDataaccess = new HrDataService(Settings);
            return hrDataaccess.UpdateUserCourseDetails(userCourseDetails);
        }
       

        public List<UserCourseDetails> SelectCourseDetails(Int64 fk_user, Int64 id_UserCourseDetails)
        {
            HrDataService hrDataaccess = new HrDataService(Settings);
            return hrDataaccess.SelectCourseDetails(fk_user, id_UserCourseDetails);
        }


        public List<DetailsCourseUser> DetailsCourseUser(Int64 fk_User)
        {
            HrDataService hrdataaccess = new HrDataService(Settings);
            return hrdataaccess.DetailsCourseUser(fk_User);

        }
    }
} 
