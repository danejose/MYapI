﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Text;
using VT.DataAccess;
using VT.DomainModel;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class CommonService : ICommonService
    {
        public GenSettings Settings { get; set; }

        public List<SelectListItem> BindDropDwonFromView(string viewName)
        {
            CommonDataService commonDataService = new CommonDataService(Settings);
            return commonDataService.BindDropDwonFromView(viewName);
        }

        public List<SelectListItem> BindDropDown(string tableName,string fields,string condition)
        {
            CommonDataService commonDataService = new CommonDataService(Settings);
            return commonDataService.BindDropDown(tableName, fields, condition);
        }
        public string GetData(string tableName, string fields, string condition)
        {
            CommonDataService commonDataService = new CommonDataService(Settings);
            return commonDataService.GetData(tableName, fields, condition);
        }

        public string DropDownData()
        {
            CommonDataService commonDataService = new CommonDataService(Settings);
            return commonDataService.DropDownData();
        }
    }
}
