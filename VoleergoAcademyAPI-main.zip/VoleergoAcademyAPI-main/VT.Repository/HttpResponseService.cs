﻿using System;
using System.Collections.Generic;
using System.Text;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class HttpResponseService : IHttpResponseService
    {
       

        public HttpResponses GetHttpSuccessResponse(HttpResponses httpResponseModel)
        {           
            try
            {
                httpResponseModel.Response = httpResponseModel.Response;
                httpResponseModel.ResponseStatus = true;
                httpResponseModel.ResponseCode = httpResponseModel.ResponseCode;
                httpResponseModel.ResponseType = httpResponseModel.ResponseType;
                httpResponseModel.ResponseMessage = httpResponseModel.ResponseMessage;
                return httpResponseModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                httpResponseModel = null;
            }
        }

        public HttpResponses GetHttpFailureResponse(HttpResponses httpResponseModel)
        {           
            try
            {
                httpResponseModel.Response = httpResponseModel.Response;
                httpResponseModel.ResponseStatus = true;
                httpResponseModel.ResponseCode = httpResponseModel.ResponseCode;
                httpResponseModel.ResponseType = httpResponseModel.ResponseType;
                httpResponseModel.ResponseMessage = httpResponseModel.ResponseMessage;
                return httpResponseModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                httpResponseModel = null;
            }
        }
    }
}
