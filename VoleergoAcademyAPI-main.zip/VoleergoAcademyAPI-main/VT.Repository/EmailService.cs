﻿using SendGrid.Helpers.Mail;
using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VT.ServiceInterfaces;

namespace VT.Repository
{
    public class EmailService : IEmailService
    {
        public Task<Response> SendEmail(EmailModel emailModel)
        {
            var client = new SendGridClient(emailModel.Token);
            var msg = MailHelper.CreateSingleEmailToMultipleRecipients(emailModel.FromEmailAddress, emailModel.ToEmailAddress, emailModel.Subject, emailModel.TextBody, emailModel.HtmlBody);
            if (!string.IsNullOrEmpty(emailModel.AttachmentFile))
            {
                msg.Attachments = new List<SendGrid.Helpers.Mail.Attachment>
                {
                    new SendGrid.Helpers.Mail.Attachment
                    {
                        Content = Convert.ToBase64String(FileToByteArray(emailModel.AttachmentFile)),
                        Filename = emailModel.AttachmentFileName,
                        Type = "txt/plain",
                        Disposition = "attachment"
                    }
                };
            }
            return client.SendEmailAsync(msg);
        }

        public Task<Response> SendForgotPassword(EmailModel emailModel)
        {
            var client = new SendGridClient(emailModel.Token);
            var msg = MailHelper.CreateSingleEmailToMultipleRecipients(emailModel.FromEmailAddress, emailModel.ToEmailAddress, emailModel.Subject, emailModel.TextBody, emailModel.HtmlBody);
            if (!string.IsNullOrEmpty(emailModel.AttachmentFile))
            {
                msg.Attachments = new List<SendGrid.Helpers.Mail.Attachment>
                {
                    new SendGrid.Helpers.Mail.Attachment
                    {
                        Content = Convert.ToBase64String(FileToByteArray(emailModel.AttachmentFile)),
                        Filename = emailModel.AttachmentFileName,
                        Type = "txt/plain",
                        Disposition = "attachment"
                    }
                };
            }
            return client.SendEmailAsync(msg);
        }

        public byte[] FileToByteArray(string fileName)
        {
            byte[] fileContent = null;
            System.IO.FileStream fs = new System.IO.FileStream(fileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader binaryReader = new System.IO.BinaryReader(fs);
            long byteLength = new System.IO.FileInfo(fileName).Length;
            fileContent = binaryReader.ReadBytes((Int32)byteLength);
            return fileContent;
        }
    }
}
