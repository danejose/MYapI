﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : Authentication Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID     Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SendGrid.Helpers.Mail;
using VLG.API.Registration.Controllers;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Common;
using VT.Common;
using VT.DomainModel.Security;
using VT.ServiceInterfaces;
using DocumentFormat.OpenXml.Spreadsheet;
using VT.DomainModel.SearchUser;
using VT.DomainModel.Question;
using VT.Repository;

namespace VT.API.Controllers
{
    [Route("v1/[action]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AuthController : BaseController
    {

        private readonly IConfiguration _configuration;      
        private readonly GenSettings? _genSettings;
        private readonly IOptions<GenSettings> _settings;
        private IWebHostEnvironment _environment;
        private readonly ICommonService _commonService;
        private readonly IAuthService _authService;
        private readonly IEmailService _emailService;
        private readonly string _emaiID = string.Empty;
        private readonly string _emailUserName = string.Empty;
        private readonly string _emailApiKey = string.Empty;
        private readonly string _clientUrl = string.Empty;
        private readonly ISearchUser _searchUser;




        public AuthController(IConfiguration config, IWebHostEnvironment environment, ISearchUser searchUser,ICommonService commonService,IAuthService authService,IEmailService emailService) : base(config)
        {
            _genSettings = new GenSettings();
            _configuration = config;           
            _environment = environment;
            _authService = authService;
            _emailService = emailService;
            _searchUser = searchUser;
            _emailApiKey = _configuration["EmailAPIKey"];
            _emailUserName = _configuration["EmailUserName"];
            _emaiID = _configuration["EmaiID"];
            _clientUrl = _configuration["ClientUrl"];

            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _configuration["ConnectionString"] ?? "";
                _genSettings.HostName = _configuration["USERNAME"] ?? "";
                _genSettings.HostUrl = _configuration["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;
          
            }
            _authService.Settings = _genSettings;
            _searchUser.Settings = _genSettings;

        }





        [HttpPost]
        [EnableCors()]
        [ActionName("resume")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public Task<IActionResult> ResumeUpdate(IFormFile? files)
        {
            UserImageResponse result = new UserImageResponse();
            IActionResult response = Unauthorized();
            string filePath = string.Empty;
            string newFileName = string.Empty, urlPath = string.Empty;
            Int32 maxLimit = 3080;
            UserUploadModel model = new UserUploadModel();
            try
            {
                Int64 id_user = base.ID_Users;
                model.IPAddress = base.IPAddress;
                model.MACAddress = base.MACAddress;
                model.ImageURL = string.Empty;
                model.ImageName = "temp";
                model.ID_UserImages = 0;
                model.ImageType = "R";
                result = _authService.UserUploadUpdate(model);



                foreach (var formFile in Request.Form.Files)
                {
                    Int64 dir = result.ResponseID % 5;                  
                    string filename = Request.Form.Files[0].FileName;
                    var fileExtension = Path.GetExtension(filename);

                    if (formFile.ContentType.Contains("pdf") || formFile.ContentType.Contains("word"))
                    {
                        if ((formFile.Length) / 1024 < maxLimit && formFile.Length > 0)
                        {
                            string dirPath = this._environment.ContentRootPath + "/upload/resume/" + dir;
                            if (!Directory.Exists(dirPath))
                            {
                                Directory.CreateDirectory(dirPath);
                            }
                            newFileName = result.ResponseID + fileExtension;                           
                            urlPath = "/upload/resume/" + dir + "/" + newFileName;
                            filePath = string.Format(dirPath + "/{0}", newFileName);
                            //Getting file Extension
                            using (var fileStream = new FileStream(filePath, FileMode.Create))
                            {
                                formFile.CopyTo(fileStream);
                                string fName = formFile.FileName;

                            }
                        }
                        else
                        {
                            result.ResponseStatus = false;
                            result.ResponseMessage = "File Limit size exeeds";
                            result.ResponseCode = "-1";
                            result.ResponseID = 0;
                            return Task.FromResult<IActionResult>(Ok(new
                            {
                                Result = result
                            }));
                        }
                    }
                    else
                    {
                        result.ResponseStatus = false;
                        result.ResponseMessage = "Selected file not an pdf/word";
                        result.ResponseCode = "-1";
                        result.ResponseID = 0;
                        return Task.FromResult<IActionResult>(Ok(new
                        {
                            Result = result
                        }));
                    }
                }
                model.ImageURL = urlPath;
                model.ImageName = newFileName;
                model.ID_UserImages = result.ResponseID;
                model.ImageType = "R";
                result = _authService.UserUploadUpdate(model);

                return Task.FromResult<IActionResult>(Ok(new
                {
                    Result = result
                }));
            }
            catch (Exception ex)
            {               
                return Task.FromResult<IActionResult>(BadRequest(new
                {
                    Result = result
                }));
            }
            finally
            {
            }
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("images")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public Task<IActionResult> ImageUpdate(IFormFile? files)
        {
            UserImageResponse result = new UserImageResponse();
            IActionResult response = Unauthorized();
            string filePath = string.Empty;
            string newFileName = string.Empty, urlPath = string.Empty;
            int maxLimit = 3080;
            UserUploadModel model = new UserUploadModel();

            try
            {
                Int64 id_user = base.ID_Users;
                model.IPAddress = base.IPAddress;
                model.MACAddress = base.MACAddress;
                model.ImageURL = string.Empty;
                model.ImageName = "temp";
                model.ID_UserImages = 0;
                model.ImageType = "R";
                result = _authService.UserUploadUpdate(model);

                foreach (var formFile in Request.Form.Files)
                {
                    Int64 dir = result.ResponseID % 5;
                    string filename = Request.Form.Files[0].FileName;
                    var fileExtension = Path.GetExtension(filename);

                    if (formFile.ContentType.Contains("image/jpeg") ||
                        formFile.ContentType.Contains("image/png") ||
                        formFile.ContentType.Contains("image/gif"))
                    {
                        if ((formFile.Length / 1024) < maxLimit && formFile.Length > 0)
                        {
                            string dirPath = this._environment.ContentRootPath + "/upload/images/" + dir;
                            if (!Directory.Exists(dirPath))
                            {
                                Directory.CreateDirectory(dirPath);
                            }
                            newFileName = result.ResponseID + fileExtension;
                            urlPath = "/upload/images/" + dir + "/" + newFileName;
                            filePath = string.Format(dirPath + "/{0}", newFileName);

                            using (var fileStream = new FileStream(filePath, FileMode.Create))
                            {
                                formFile.CopyTo(fileStream);
                            }
                        }
                        else
                        {
                            result.ResponseStatus = false;
                            result.ResponseMessage = "File size exceeds the limit";
                            result.ResponseCode = "-1";
                            result.ResponseID = 0;
                            return Task.FromResult<IActionResult>(Ok(new
                            {
                                Result = result
                            }));
                        }
                    }
                    else
                    {
                        result.ResponseStatus = false;
                        result.ResponseMessage = "Selected file is not a supported image type (JPEG/PNG/GIF)";
                        result.ResponseCode = "-1";
                        result.ResponseID = 0;
                        return Task.FromResult<IActionResult>(Ok(new
                        {
                            Result = result
                        }));
                    }
                }

                model.ImageURL = urlPath;
                model.ImageName = newFileName;
                model.ID_UserImages = result.ResponseID;
                model.ImageType = "R";
                result = _authService.UserUploadUpdate(model);

                return Task.FromResult<IActionResult>(Ok(new
                {
                    Result = result
                }));
            }
            catch (Exception ex)
            {
                return Task.FromResult<IActionResult>(BadRequest(new
                {
                    Result = result
                }));
            }
        }

        [HttpPost]
        [EnableCors()]
        [ActionName("searchuser")]
        [ApiExplorerSettings(IgnoreApi = false)]

        public IActionResult SearchUser(SearchUserModel search)
        {
            IActionResult response = Unauthorized();
            try
            {
                var result = _searchUser.Search(search);
                return response = Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });
            }

        }


   

        [HttpPost]
        [EnableCors()]
        [ActionName("register")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UserRegister(RegisterModel user)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            UserUploadModel model = new UserUploadModel();
            try
            {
                model.IPAddress = base.IPAddress;
                model.MACAddress = base.MACAddress;
                result = _authService.RegisterUser(user);
                if (result.ResponseID > 0)
                {
                    SendEmail(user);
                }
                return response = Ok(new { Result = result });
            }
            catch(Exception ex)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }

        private void SendEmail(RegisterModel model)
        {

            IActionResult response = Unauthorized();
            EmailModel emailModel = new EmailModel();
            string templatePath = this._environment.ContentRootPath + "\\emailtemplate\\Template.html";

            emailModel.FromEmailAddress = new EmailAddress(_emaiID, _emailUserName);
            emailModel.FromAddress = _emaiID;
            emailModel.Subject = "Welcome to Voleergo Academy: " + model.FirstName + "  " + model.LastName;
            emailModel.EmailID = model.Email;
            emailModel.TextBody = "";
            emailModel.ClientUrl = _clientUrl;
            emailModel.HtmlBody = EmailTemplateEditores.EditTemplate(templatePath, emailModel, model.PasswordStr, "Thank you for registering, Voleergo Academy!", model.PasswordStr);
            emailModel.AttachmentFile = String.Empty;
            emailModel.AttachmentFileName = String.Empty;
            emailModel.Token = _emailApiKey;
           
            emailModel.ToEmailAddress.Add(new EmailAddress(model.Email, model.FirstName));
            _emailService.SendEmail(emailModel);

        }

        [HttpPost]
        [EnableCors()]
        [ActionName("login")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult Login(LoginModel loginuser)
        {
            HttpLoginResponse result = new HttpLoginResponse();
            IActionResult response = Unauthorized();
            UserUploadModel model = new UserUploadModel();

            try
            {
                model.IPAddress = base.IPAddress;
                model.MACAddress = base.MACAddress;
                result = _authService.LoginUser(loginuser);               
                return response = Ok(new { Result = result });
            }catch(Exception ex)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("changePassword")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult ChangePassword(ChangePasswordModel changePasswordModel)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _authService.ChangePassword(changePasswordModel);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });

            }
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("userRights")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UserRights(UserRights userRights)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _authService.UserRights(userRights);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });

            }
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("forgotpassword")]
        public IActionResult ForgotPassword(RegisterModel user)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
               result = _authService.forgotPasssword(user);
                if (result.ResponseID > 0)
                {
                    SendForgotPassword(user);
                }
                return response = Ok(new {Result = result});
            }catch(Exception err)
            {
                return response = BadRequest(new { Result = 0 });
            }

        }

        private void SendForgotPassword(RegisterModel model)
        {
            IActionResult response = Unauthorized();
            EmailModel emailModel = new EmailModel();
            string templatePath = this._environment.ContentRootPath + "\\emailtemplate\\ForgotPassword.html";

            emailModel.FromEmailAddress = new EmailAddress(_emaiID, _emailUserName);
            emailModel.FromAddress = _emaiID;
            emailModel.Subject = "ForgotPassword Mail to " + model.FirstName + "  " + model.LastName;
            emailModel.EmailID = model.Email;
            emailModel.TextBody = "";
            emailModel.ClientUrl = _clientUrl;
            emailModel.HtmlBody = EmailTemplateEditores.EditTemplate(templatePath, emailModel, model.PasswordStr, "", model.PasswordStr);
            emailModel.AttachmentFile = String.Empty;
            emailModel.AttachmentFileName = String.Empty;
            emailModel.Token = _emailApiKey;

            emailModel.ToEmailAddress.Add(new EmailAddress(model.Email, model.FirstName));
            _emailService.SendForgotPassword(emailModel);
        }
    }
}
