﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : HR Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID     Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Asn1.Crmf;
using VLG.API.Registration.Controllers;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel.StudentHistory;
using VT.DomainModel.StudentProfile;
using VT.DomainModel.StudentAdditionalDetails;
using VT.Repository;
using VT.ServiceInterfaces;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using VT.DomainModel.HR;
using VT.DomainModel.Question;
using VT.DomainModel.MockInterview;
using System.Buffers;

namespace VT.API.Controllers
{
    [Route("v1/[action]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class HRController : BaseController
    {
        private readonly IConfiguration _configuration;
        private IWebHostEnvironment _environment;
        private readonly GenSettings? _genSettings;
        private readonly IOptions<GenSettings> _settings;
        private readonly IHrService _hrService;

        public HRController(IConfiguration config, IWebHostEnvironment environment, IHrService hrService) : base(config)
        {
            _genSettings = new GenSettings();
            _configuration = config;
            _hrService = hrService;
            _environment = environment;
            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _configuration["ConnectionString"] ?? "";
                _genSettings.HostName = _configuration["USERNAME"] ?? "";
                _genSettings.HostUrl = _configuration["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;

            }
            _hrService.Settings = _genSettings;
        }
        
        [HttpGet]
        [EnableCors()]
        [ActionName("courseregistereduser")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult SelectCourseRegisteredUser(Int64 fk_User,string? searchValue, string? fetchType)
        {
            List<CourseRegisteredStudent> result = new List<CourseRegisteredStudent>();
            IActionResult response = Unauthorized();
            try
            {
                result = _hrService.SelectCourseRegisteredUser(fk_User, searchValue, fetchType);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }


        
        [HttpPost]
        [EnableCors()]
        [ActionName("courseregistration")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UpdateCourseRegistration(CourseRegisteredStudent courseRegisteredStudent)
        {
            VLG.DomainModel.HttpResponses result = new VLG.DomainModel.HttpResponses();  
            try
            {
                result = _hrService.UpdateCourseRegistration(courseRegisteredStudent);  

                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });  
            }
        }


        /// <summary>
        /// To fetch all entered Details of user 
        /// </summary>
        /// <param name="fk_User"></param>
        /// <returns></returns>

        [HttpGet]
        [EnableCors()]
        [ActionName("DetailsCourseUser")]
        [ApiExplorerSettings(IgnoreApi = false)]

        public IActionResult DetailsCourseUser(Int64 fk_User)
        {
            List<DetailsCourseUser> result = new List<DetailsCourseUser>();
            IActionResult response = Unauthorized();
            try
            {
                result = _hrService.DetailsCourseUser(fk_User);
                return Ok(new { Result = result });

            }
            catch (Exception ex)
            {

                return BadRequest(new { Result = 0 });


            }  
        }
        [HttpGet]
        [EnableCors()]
        [ActionName("selectregisteredcourse")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult SelectRegisteredCourse(Int64? id_userRegistration, string? searchValue, string? fetchType)
        {
            List<UserRegisteredCourse> result = new List<UserRegisteredCourse>();
            IActionResult response = Unauthorized();
            try
            {
                result = _hrService.SelectRegisteredCourse(id_userRegistration, searchValue, fetchType);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }

        [HttpGet]
        [EnableCors()]
        [ActionName("registereduser")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult SelectRegisteredUser(Int64? id_user, string? searchValue, string? fetchType)
        {
            List<RegisteredUser> result = new List<RegisteredUser>();
            IActionResult response = Unauthorized();
            try
            {
                result = _hrService.SelectRegisteredUser(id_user, searchValue, fetchType);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }
      

        [HttpPost]
        [EnableCors()]
        [ActionName("registereduser")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UpdateRegisteredUser(RegisteredStudent studentHistory)
        {
            VLG.DomainModel.HttpResponses result = new VLG.DomainModel.HttpResponses();
            try
            {
                result = _hrService.UpdateRegisteredUser(studentHistory);

                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }

        
        [HttpPost]
        [EnableCors()]
        [ActionName("usercoursedetails")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UpdateUserCourseDetails(UserCourseDetails userCourseDetails)
        {
            VLG.DomainModel.HttpResponses result = new VLG.DomainModel.HttpResponses();
            try
            {
                result = _hrService.UpdateUserCourseDetails(userCourseDetails);

                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("studentProfile")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult StudentProfile(StudentProfile studentProfile)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _hrService.StudentProfile(studentProfile);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });

            }
        }

        [HttpGet]
        [EnableCors()]
        [ActionName("usercoursedetails")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult SelectCourseDetails(Int64 fk_user,Int64 id_UserCourseDetails)
        {
            List< UserCourseDetails> result = new List<UserCourseDetails>();
            try
            {
                result = _hrService.SelectCourseDetails(fk_user, id_UserCourseDetails);

                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }

        [HttpGet]
        [EnableCors()]
        [ActionName("userregistered")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UserRegistered(Int64 id_userregistration)
        {
            List<UserRegistered> result = new List<UserRegistered>();
            try
            {
                result = _hrService.UserRegistered(id_userregistration);

                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }

    }
}
