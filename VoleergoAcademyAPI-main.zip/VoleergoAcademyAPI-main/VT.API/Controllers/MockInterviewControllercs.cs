﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : HR Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID     Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Org.BouncyCastle.Asn1.Crmf;
using VLG.API.Registration.Controllers;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel.StudentHistory;
using VT.DomainModel.StudentProfile;
using VT.DomainModel.StudentAdditionalDetails;
using VT.Repository;
using VT.ServiceInterfaces;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using VT.DomainModel.HR;
using VT.DomainModel.Question;
using VT.DomainModel.MockInterview;

namespace VT.API.Controllers
{
    [Route("v1/[action]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class MockInterviewController : BaseController
    {
        private readonly IConfiguration _configuration;
        private IWebHostEnvironment _environment;
        private readonly GenSettings? _genSettings;
        private readonly IOptions<GenSettings> _settings;
        private readonly IMockInterview _mockService;

        public MockInterviewController(IConfiguration config, IWebHostEnvironment environment, IMockInterview mockService) : base(config)
        {
            _genSettings = new GenSettings();
            _configuration = config;
            _mockService = mockService;
            _environment = environment;
            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _configuration["ConnectionString"] ?? "";
                _genSettings.HostName = _configuration["USERNAME"] ?? "";
                _genSettings.HostUrl = _configuration["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;

            }
            _mockService.Settings = _genSettings;
        }

        [HttpGet]
        [EnableCors()]
        [ActionName("MockInterviewQuestions")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult SelectMockInterviewQuestion(Int64 fk_InterviewCourse, Int64 fk_InterviewLevel, Int64 fk_User)
        {
            List<MockInterviewModel> result = new List<MockInterviewModel>();
            IActionResult response = Unauthorized();
            try
            {
                result = _mockService.SelectMockInterviewQuestion(fk_InterviewCourse, fk_InterviewLevel, fk_User);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }
        [HttpGet]
        [EnableCors()]
        [ActionName("dashBoardSection")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult DashBoardSection(Int64 fk_User)
        {
            List<DashboardSection> result = new List<DashboardSection>();
            IActionResult response = Unauthorized();
            try
            {
                result = _mockService.DashBoardSection(fk_User);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }
        [HttpGet]
        [EnableCors()]
        [ActionName("dashBoardSection1")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult DashBoardSection1(Int64 fk_User)
        {
            List<DashboardSection1> result = new List<DashboardSection1>();
            IActionResult response = Unauthorized();
            try
            {
                result = _mockService.DashBoardSection1(fk_User);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }
        [HttpGet]
        [EnableCors()]
        [ActionName("dashBoardSectionReview")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult DashBoardSectionReview(Int64 id_MockInterviewQuestion)
        {
            List<DashboardSectionReviewList> result = new List<DashboardSectionReviewList>();
            IActionResult response = Unauthorized();
            try
            {
                result = _mockService.DashBoardSectionReview(id_MockInterviewQuestion);
                return Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return BadRequest(new { Result = 0 });
            }
        }

        [HttpPost]
        [EnableCors()]
        [ActionName("MockInterviewQuestionDetails")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UpdateMockInterviewQuestionDetails(MockInterviewModel mockInterviewModel)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _mockService.UpdateMockInterviewQuestionDetails(mockInterviewModel);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });

            }
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("MockInterviewQuestions")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UpdateMockInterviewQuestion(MockInterviewModel mockInterviewModel)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _mockService.UpdateMockInterviewQuestion(mockInterviewModel);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });

            }
        }






    }
}
