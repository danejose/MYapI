﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : Admin Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID                    Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID :  Abhishek R      Description :  Created Post Get and Delete routes for mock interview
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 18/10/2024	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/


using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using VLG.API.Registration.Controllers;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Master;
using VT.DomainModel.Question;
using VT.ServiceInterfaces;

namespace VT.API.Controllers
{

    [Route("v1/[action]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class AdminController : BaseController
    {

        private readonly IConfiguration _configuration;
        private readonly GenSettings? _genSettings;
        private readonly IOptions<GenSettings> _settings;
        private IWebHostEnvironment _environment;
        private readonly ICommonService _commonService;
        //private readonly IEmailService _emailService;
        private readonly IAdminService _adminService;
        //private readonly string _emaiID = string.Empty;
        //private readonly string _emailUserName = string.Empty;
        //private readonly string _emailApiKey = string.Empty;
        //private readonly string _clientUrl = string.Empty;

        public AdminController(IConfiguration config, IWebHostEnvironment environment, ICommonService commonService, IAdminService adminService) : base(config)
        {
            _genSettings = new GenSettings();
            _configuration = config;
            _environment = environment;
            _adminService = adminService;
            //_emailService = emailService;
            //_emailApiKey = _configuration["EmailAPIKey"];
            //_emailUserName = _configuration["EmailUserName"];
            //_emaiID = _configuration["EmaiID"];
            //_clientUrl = _configuration["ClientUrl"];

            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _configuration["ConnectionString"] ?? "";
                _genSettings.HostName = _configuration["USERNAME"] ?? "";
                _genSettings.HostUrl = _configuration["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;


            }
            _adminService.Settings = _genSettings;
        }

        #region Question
        /// <summary>
        /// Get Api - For fetching questions with ID
        /// </summary>
        /// <param name="id_Course"></param>        /// <returns></returns>
        
        [HttpGet]
        [ActionName("Question")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult SelectQuestion(int id_Course)
        {
            QuestionModel question = new QuestionModel();
            IActionResult response = Unauthorized();
            try
            {
                question.Id_Course = id_Course;
                var result = _adminService.SelectQuestion(question);
                return response = Ok(new { Result = result });
            }
            catch (Exception e)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }  


        /// <summary>
        /// Post Api - For posting questions in UI
        /// </summary>
        /// <param name="options"></param>
        /// <returns></returns>
        
        [HttpPost]
        [EnableCors()]
        [ActionName("Question")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult UpdateQuestion(QuestionModel options)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _adminService.UpdateQuestion(options);
                return response = Ok(new { Result = result });
            }
            catch (Exception ex)
            {

                return response = BadRequest(new { Result = 0 });

            }
        }

        /// <summary>
        /// Delete Api - To delete questions with respect to questionId
        /// </summary>
        /// <param name="questionId"></param>
        /// <returns></returns>

        [HttpDelete]
        [ActionName("Question")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]

        public IActionResult DeleteQuestion(int questionId)
        {

            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _adminService.DeleteQuestion(questionId);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new {Result = 0});

            }
        }

        [HttpGet]
        [ActionName("menuaccess")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult MenuAccess(int fk_user)
        {
           IActionResult response = Unauthorized();
            try
            {
                var result = _adminService.UserMenus(fk_user);
                return response = Ok(new {Result = result});
            }catch(Exception ex)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }

    };
}

#endregion