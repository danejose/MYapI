﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : Authentication Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID     Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using SendGrid.Helpers.Mail;
using VLG.API.Registration.Controllers;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Common;
using VT.Common;
using VT.DomainModel.Security;
using VT.ServiceInterfaces;
using DocumentFormat.OpenXml.Spreadsheet;
using VT.DomainModel.SearchUser;
using VT.DomainModel.HR;
using VT.Repository;
using VT.DomainModel.Question;
using VT.DomainModel.Result;

namespace VT.API.Controllers
{
    [Route("v1/[action]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class CourseControlller : BaseController
    {

        private readonly IConfiguration _configuration;
        private readonly GenSettings? _genSettings;
        private readonly IOptions<GenSettings> _settings;
        private IWebHostEnvironment _environment;
        private readonly ICommonService _commonService;
        private readonly ICourseService _courseService;
        private readonly IEmailService _emailService;
        private readonly string _emaiID = string.Empty;
        private readonly string _emailUserName = string.Empty;
        private readonly string _emailApiKey = string.Empty;
        private readonly string _clientUrl = string.Empty;
        private readonly ISearchUser _searchUser;




        public CourseControlller(IConfiguration config, IWebHostEnvironment environment, ISearchUser searchUser, ICommonService commonService, ICourseService courseService, IEmailService emailService) : base(config)
        {
            _genSettings = new GenSettings();
            _configuration = config;
            _environment = environment;
            _courseService = courseService;
            _emailService = emailService;
            _searchUser = searchUser;
            _emailApiKey = _configuration["EmailAPIKey"];
            _emailUserName = _configuration["EmailUserName"];
            _emaiID = _configuration["EmaiID"];
            _clientUrl = _configuration["ClientUrl"];

            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _configuration["ConnectionString"] ?? "";
                _genSettings.HostName = _configuration["USERNAME"] ?? "";
                _genSettings.HostUrl = _configuration["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;

            }
            _courseService.Settings = _genSettings;
            _searchUser.Settings = _genSettings;

        }
        [HttpGet]
        [EnableCors()]
        [ActionName("questionsel")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult QuestionSelect(int id_Course, int level)
        {
            IActionResult response;
            try
            {
                List<QuestionModel> result = _courseService.QuestionSelect(id_Course, level);
                response = Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                response = BadRequest(new { Result = 0 });
            }
            return response;
        }
        [HttpPost]
        [EnableCors()]
        [ActionName("questionsl")]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult Questionsl(QuestionModel options)
        {
            HttpResponses result = new HttpResponses();
            IActionResult response = Unauthorized();
            try
            {
                result = _courseService.Questionsl(options);
                return response = Ok(new { Result = result });

            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });

            }
        }
   



        //[HttpGet]
        //[EnableCors()]
        //[ActionName("Result")]
        //[ApiExplorerSettings(IgnoreApi = false)]

        //public IActionResult result(ResultModel resultModel)
        //{
        //    IActionResult response;
        //    try
        //    {
        //        List<ResultModel> result = _courseService.result(resultModel);
        //        response = Ok(new { Result = result });

        //    }
        //    catch (Exception ex)  
        //    {
        //        response = BadRequest(new { Result = 0 });

        //    }
        //    return response;
        //}



    }
}
