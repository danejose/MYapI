﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : Common Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID     Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Options;
using VLG.API.Registration.Controllers;
using VT.DomainModel;
using VT.Repository;
using DocumentFormat.OpenXml.Packaging;
using static Org.BouncyCastle.Math.EC.ECCurve;
using System;
using VT.ServiceInterfaces;


namespace VT.API.Controllers
{
    [Route("v1/[action]")]
    [ApiController] 
    public class CommonController : Controller
    {
        private readonly ILogger<CommonController> _logger;
        private readonly IOptions<GenSettings> _settings;
        private new readonly IConfiguration _config;
        private readonly GenSettings _genSettings;
        private IWebHostEnvironment _environment;
        private readonly ICommonService _commonService;
        public CommonController(ILoggerFactory loggerFactory, IConfiguration config, IOptions<GenSettings> settings, IWebHostEnvironment environment, ICommonService commonService)
        {
            _logger = loggerFactory.CreateLogger<CommonController>();
            _config = config;
            _genSettings = new GenSettings();
            _environment = environment;
            _commonService = commonService;

            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _config["ConnectionString"] ?? "";
                _genSettings.HostName = _config["USERNAME"] ?? "";
                _genSettings.HostUrl = _config["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;

            }
            _commonService.Settings = _genSettings;
        }

        [HttpGet]
        [ActionName("BindDropDown")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult BindDropDown(string tableName, string fieldName, string condition)
        {
            IActionResult response = Unauthorized();
            CommonService common = new CommonService();
            try
            { 
                condition = condition == null ? "" : condition;
                var result = _commonService.BindDropDown(tableName, fieldName, condition);
                return response = Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }
        [HttpGet]
        [ActionName("GetData")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult GetData(string tableName, string fieldName, string condition)
        {
            IActionResult response = Unauthorized();
            CommonService common = new CommonService();
            try
            {
                condition = condition == null ? "" : condition;
                var result = _commonService.GetData(tableName, fieldName, condition);
                return response = Ok(new { Result = result });
            }
            catch (Exception ex)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }

        [HttpGet]
        [ActionName("DropDownData")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult DropDownData()
        {
            IActionResult response = Unauthorized();
            try
            {
                var result = _commonService.DropDownData();
                return response = Ok(new { Result = result });
            }catch(Exception ex)
            {
                return response = BadRequest(new {Result = 0});
            }
            
        }
    }
}
