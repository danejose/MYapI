﻿/*----------------------------------- Model Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : Masterfile Controller
Author     : Voleergo
Copyright  : Voleergo Technologies       
Created on : 16/10/2024
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			  By			        Ticket ID     Description
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
 14/05/2021	  Voleergo	 	    
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Driver.Core.Connections;
using VLG.API.Registration.Controllers;
using VT.DomainModel;
using VT.DomainModel.Master;
using VT.Repository;
using VT.ServiceInterfaces;
namespace VT.API.Controllers
{
    [Route("v1/[action]")]
    [ApiController]
    [ApiExplorerSettings(IgnoreApi = true)]
    public class MasterFileController : BaseController
    {
        private readonly IConfiguration _configuration;
        private readonly IMasterService _masterService;
        private readonly GenSettings _genSettings;
        private readonly IOptions<GenSettings> _settings;
        private IWebHostEnvironment _environment;
        private readonly ICommonService _commonService;

        public MasterFileController(IConfiguration config,IMasterService masterService, IWebHostEnvironment environment, ICommonService commonService) : base(config)
        {
            _genSettings = new GenSettings();
            _configuration = config;
            _masterService = masterService;
            _environment = environment;
            if (_genSettings is not null)
            {
                _genSettings.ConnectionStrings = _configuration["ConnectionString"] ?? "";
                _genSettings.HostName = _configuration["USERNAME"] ?? "";
                _genSettings.HostUrl = _configuration["ASPNETCORE_URLS"] ?? "";
                _genSettings.Enviournment = _environment.EnvironmentName;

            }
            _masterService.Settings = _genSettings;
        }

        [HttpGet]
        [ActionName("course")]
        [EnableCors()]
        [ApiExplorerSettings(IgnoreApi = false)]
        public IActionResult CourseGet(int id_Course)
        {
            CourseDomainModel course = new CourseDomainModel();
            IActionResult response = Unauthorized();
            try
            {
                course.ID = id_Course;
                var result = _masterService.CourseGet(course);
                return response = Ok(new { Result = result });
            }
            catch (Exception e)
            {
                return response = BadRequest(new { Result = 0 });
            }
        }
    }
}
