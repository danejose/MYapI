﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VT.DomainModel;

namespace VT.ServiceInterfaces
{
    public interface ICommonService
    {
        public GenSettings Settings { get; set; }
        List<SelectListItem> BindDropDwonFromView(string viewName);
        List<SelectListItem> BindDropDown(string tableName, string fields, string condition);
        string GetData(string tableName, string fields, string condition);
        string DropDownData();
    }
}
