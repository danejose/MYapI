﻿using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.HR;
using VT.DomainModel.Question;
using VT.DomainModel.Result;

namespace VT.ServiceInterfaces
{
    public interface ICourseService
    {
        public GenSettings Settings { get; set; }

     //   List<ResultModel> result(ResultModel resultModel);
        List<QuestionModel> QuestionSelect(int id_Course, int level);
        HttpResponses Questionsl(QuestionModel options);


    }
}
