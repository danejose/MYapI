﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VT.DomainModel;
using VT.DomainModel.Master;

namespace VT.ServiceInterfaces
{
    public interface IMasterService
    {
        public GenSettings Settings { get; set; }
        List<CourseDomainModel> CourseGet(CourseDomainModel course);
    }
}
