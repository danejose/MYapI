﻿using System;
using System.Collections.Generic;
using System.Text;
using VLG.DomainModel;
using VT.DomainModel;

namespace VT.ServiceInterfaces
{
    public interface IHttpResponseService
    {
        HttpResponses GetHttpSuccessResponse(HttpResponses httpResponseModel);
        HttpResponses GetHttpFailureResponse(HttpResponses httpResponseModel);


    }
}
