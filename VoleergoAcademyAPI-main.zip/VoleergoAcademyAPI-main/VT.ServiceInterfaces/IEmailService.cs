﻿using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;

namespace VT.ServiceInterfaces
{
    public interface IEmailService
    {
        Task<Response> SendEmail(EmailModel email);
        Task<Response> SendForgotPassword(EmailModel email);
    }
}
