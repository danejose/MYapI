﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel.MockInterview;
using VT.DomainModel.Question;
using VT.DomainModel.StudentHistory;

namespace VT.ServiceInterfaces
{
    public interface IMockInterview
    {
        public GenSettings Settings { get; set; }

        List<MockInterviewModel> SelectMockInterviewQuestion(Int64 fk_InterviewCourse, Int64 fk_InterviewLevel, Int64 fk_User);
        List<DashboardSection1> DashBoardSection1(Int64 fk_User);
        List<DashboardSectionReviewList> DashBoardSectionReview(Int64 id_MockInterviewQuestion);

        HttpResponses UpdateMockInterviewQuestionDetails(MockInterviewModel mockInterviewModel);
        HttpResponses UpdateMockInterviewQuestion(MockInterviewModel mockInterviewModel);
        List<DashboardSection> DashBoardSection(Int64 fk_User);



    }
}
