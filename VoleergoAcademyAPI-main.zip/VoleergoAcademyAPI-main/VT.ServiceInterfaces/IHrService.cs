﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel.StudentHistory;
using VT.DomainModel.StudentProfile;
using VT.DomainModel.StudentAdditionalDetails;
using VT.DomainModel.HR;
using VT.DomainModel.MockInterview;

namespace VT.ServiceInterfaces
{
    public interface IHrService
    {
        public GenSettings Settings { get; set; }

        List <CourseRegisteredStudent> SelectCourseRegisteredUser(Int64 fk_User, string? searchValue, string? fetchType);

        List<RegisteredUser> SelectRegisteredUser(Int64? id_user, string? searchValue, string? fetchType);
        List<UserRegisteredCourse> SelectRegisteredCourse(Int64? id_userRegistration, string? searchValue, string? fetchType);
        List<UserRegistered> UserRegistered(Int64? id_userregistration);


        HttpResponses UpdateCourseRegistration(CourseRegisteredStudent courseRegisteredStudent);
        HttpResponses UpdateRegisteredUser(RegisteredStudent registeredStudent);

        //HttpResponses StudentData(RegisteredStudent student);
        HttpResponses StudentProfile(StudentProfile studentProfile);
        HttpResponses UpdateUserCourseDetails(UserCourseDetails userCourseDetails);

        List<UserCourseDetails> SelectCourseDetails(Int64 fk_user, Int64 id_UserCourseDetails);

        List<DetailsCourseUser> DetailsCourseUser(Int64 fk_user);



    }
}
