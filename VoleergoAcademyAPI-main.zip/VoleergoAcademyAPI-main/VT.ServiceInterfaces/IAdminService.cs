﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VT.DomainModel;
using VT.DomainModel.Master;
using VT.DomainModel.Question;

namespace VT.ServiceInterfaces
{
    public interface IAdminService
    {

        public GenSettings Settings { get; set; }
        HttpResponses UpdateQuestion(QuestionModel options);
        HttpResponses DeleteQuestion(int questionId);
        List<QuestionModel> SelectQuestion(QuestionModel question);
        string UserMenus(int fk_user);
    }
}
