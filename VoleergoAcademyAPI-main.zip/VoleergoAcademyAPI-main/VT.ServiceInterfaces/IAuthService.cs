﻿using SendGrid;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VLG.DomainModel;
using VLG.DomainModel.Auth;
using VT.DomainModel;
using VT.DomainModel.Auth;
using VT.DomainModel.Question;

namespace VT.ServiceInterfaces
{
    public interface IAuthService
    {
        public GenSettings Settings { get; set; }

        UserImageResponse UserUploadUpdate(UserUploadModel userUpload);
        HttpResponses RegisterUser(RegisterModel user);
        HttpResponses UserRights(UserRights userRights);

        HttpLoginResponse LoginUser(LoginModel loginuser);
        HttpResponses ChangePassword(ChangePasswordModel changePasswordModel);
        HttpResponses forgotPasssword(RegisterModel model);
    }
}
