﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VT.DomainModel;
using VT.DomainModel.SearchUser;

namespace VT.ServiceInterfaces
{
    public interface ISearchUser
    {
        public GenSettings Settings { get; set; }
        List<SearchUserModel> Search(SearchUserModel searchUser);
    }
}
