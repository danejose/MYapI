﻿using EllipticCurve.Utils;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.Common
{
    public static class StringManipulator
    {
        public static string GetStringFromText(string text, string word)
        {
            int ix = text.IndexOf(word);
            if (ix != -1)
            {
                return text.Substring(ix + word.Length);

            }
            else
            {
                return string.Empty;
            }
        }
    }
}
