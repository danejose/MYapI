﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VT.Common
{
    public enum UserAction : int
    {
        Insert = 1,
        Update=2,
        Select=3,
        Delete=4,
        Login=5
    }
    public enum LogType : int
    {
        Information = 1,
        Error = 2
    }


}
