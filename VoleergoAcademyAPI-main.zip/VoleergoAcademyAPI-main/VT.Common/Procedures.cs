﻿/*----------------------------------- Data Access Repository Class -----------------------------------------------------------------------------------------------------------------------
Purpose    : 
Author     : Jinesh Kumar C
Copyright  : Voleergo Technologies
Created on : 22/05/2019
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
MODIFICATIONS 
On			By			
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
22/05/2019	Jinesh Kumar C		
16/05/2021  Athul TP    Added Procedure SP_POS_GetPurchaseItemDetails(Purchase Grid Item)
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace VT.Common
{
    public static class Procedures
    {
        
        public const string SP_CampusRegistrationUpdate = "usp_CampusRegistrationUpdate";

        public const string SP_ErrorLogUpdate = "usp_ErrorLogInsert";
        //Notifications
        public const string SP_Get_EmailConfiguration = "usp_GetEmailConfiguration";
        public const string SP_Get_EmailNotifications = "usp_GetEmailNotifications";
        public const string SP_Update_EmailNotifications = "usp_UpdateEmailNotifications";
        public const string SP_Get_SMSConfiguration = "usp_GetSMSConfiguration";
        public const string SP_Get_SMSNotifications = "usp_GetSMSNotifications";
        public const string SP_Update_SMSNotifications = "usp_UpdateSMSNotifications";
        public const string SP_Get_ApplicationNotifications = "usp_GetApplicationNotifications";
        public const string SP_Update_ApplicationNotifications = "usp_UpdateApplicationNotifications";

        //Course_Get
        public const string SP_SelectCourse = "usp_SelectCourse";
        //UserUploadUpdate
        public const string SP_UpdateUserUpload = "usp_UpdateUserUpload";
        //UserRegisterationUpdate
        public const string SP_UserRegistrationUpdate = "usp_UpdateUserRegistration";

        //Login
        public const string SP_ValidateLogin = "usp_ValidateLogin";

        //ChangePassword
        public const string SP_ChangePassword = "usp_ChangePassword";

        //SelectUserRegistartion
        public const string SP_SelectUserCourseRegistration = "usp_SelectUserCourseRegistration";

        //Search 
        public const string SP_UserSearchByHR = "usp_UserSearchByHR";

        //UserRights
        public const string SP_UpdateUserRights = "usp_UpdateUserRights";


        //StudentHistory
        public const string SP_SelectUserCourseHistory = "usp_SelectUserCourseHistory";
        public const string SP_UpdateUserCourseRegistration = "usp_UpdateUserCourseRegistration";

        //InterviewQuestion
        public const string SP_UpdateInterviewQuestions = "usp_UpdateInterviewQuestions";
        public const string SP_UpdateUserProfile = "usp_UpdateUserProfile";
        public const string SP_UserCourseRegistrationUpdate = "USP_UserCourseRegistrationUpdate";
        public const string SP_SelectDropDownData = "usp_SelectDropDownData";
        //Mock Interview
        public const string SP_SelectMockRandomInterviewQuestions = "usp_SelectMockRandomInterviewQuestions";
        public const string SP_SelectMockInterviewQuestionsDetails = "usp_SelectMockInterviewQuestionDetails";
        public const string SP_SelectMockInterviewDashboard = "usp_SelectMockInterviewDashboard";

        
        public const string SP_UpdateMockInterviewQuestionDetails = "usp_UpdateMockInterviewQuestionDetails";
        public const string SP_UpdateMockInterviewQuestion = "usp_UpdateMockInterviewQuestion";
        public const string SP_SelectMockInterviewQuestion = "usp_SelectMockInterviewQuestion";


        //Questions
        public const string SP_SelectInterviewQuestion = "usp_SelectInterviewQuestion";
        public const string SP_DeleteMockInterviewQuestion = "usp_DeleteMockInterviewQuestion";
        public const string SP_SelectRegisterdUser = "usp_SelectRegisterdUser";
        public const string SP_SelectUserCourseDetails = "usp_SelectUserCourseDetails";
        public const string SP_SelectRandomInterviewQuestions = "usp_SelectRandomInterviewQuestions";
        public const string SP_UpdateMockInterviewResult = "usp_UpdateMockInterviewResult";
        public const string SP_UpdateUserCourseDetails = "usp_UpdateUserCourseDetails";
        public const string SP_SelectLatestUserCourseDetails = "usp_SelectLatestUserCourseDetails";

        //Forgot password
        public const string SP_updatepassword = "usp_updatePassword";

        //Menuaccess
        public const string SP_MenuName = "usp_SelectMENUNAME";

        //User Registration
        public const string SP_SelectRegisteredUserCourseDetail = "usp_SelectRegisteredUserCourseDetails";

    }
}
