﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.Common
{
    public class ApplicationSettings
    {
        enum AppSettings
        {
            SESSIONTIMEOUT = 1,
            PWDMINLENGTH = 2,
            PWDMINUPPER = 3,
            PWDMINLOWER = 4,
            PWDMINNUMBER = 5,
            PWDMINSPCHAR = 6,
            PWDEXPIRYDATE = 7,
            PWDRETRYCOUNT = 8,
            PWDRETRYEXPIREDDATE = 9
        }
    }
}
