﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime;
using System.Text;
using VT.DomainModel.Security;
using VT.Common;



namespace VT.DomainModel.Common
{
    public static class EmailTemplateEditor
    {
        //public static string EditTemplate(string templatePath, EmailModel emailModel, Ticket ticket,string baseUrl)
        //{
        //    NotificationTask notificationTask = new NotificationTask();
        //    string ticketBody = ticket.TicketNumber + ": " + ticket.TicketDescription;
        //    string returnUrl = "/Ticket/TicketEmailView?sid=" + Cryptography.EncryptBase64("emailview") + "&sid1=" + Cryptography.EncryptBase64(ticket.ID_Ticket.ToString());
        //    string emailLink = baseUrl + "/Security/Login?returnurl=" + Cryptography.EncryptBase64(returnUrl);
        //    StreamReader str = new StreamReader(templatePath);
        //    string MailText = str.ReadToEnd();
        //    str.Close();            
        //    MailText = MailText.Replace("~1~", emailModel.Subject).Replace("~2~", ticketBody).Replace("~3~", ticket.TicketPriority).Replace("~4~", emailLink).Replace("~5~", " to view Ticket");
        //    MailText = MailText.Replace("~7~", ticket.CretedUser);
        //    MailText = MailText.Replace("~8~", "Voleergo Solution LLP");
        //    return MailText;
        //}

        //public static string OTPTemplate(string templatePath, EmailModel emailModel, UserModel ticket, string baseUrl, OneTimePassword oneTimePassword)
        //{
        //    NotificationTask notificationTask = new NotificationTask();
        //    string ticketBody ="The OTP for user registration:" + oneTimePassword.OtpNumber;           
        //    StreamReader str = new StreamReader(templatePath);
        //    string MailText = str.ReadToEnd();
        //    str.Close();
        //    MailText = MailText.Replace("~1~", emailModel.Subject);
        //    MailText = MailText.Replace("~2~", ticketBody);          
        //    MailText = MailText.Replace("~3~", "Voleergo Solution LLP");
        //    return MailText;
        //}

        ///* ---------------------------------------------------------*/

        //public static string ForgotPasswordTemplate(string templatePath, EmailModel emailModel, string password)
        //{
        //    NotificationTask notificationTask = new NotificationTask();
        //    string ticketBody = "Your temporary password is:" + password;
        //    StreamReader str = new StreamReader(templatePath);
        //    string MailText = str.ReadToEnd();
        //    str.Close();
        //    MailText = MailText.Replace("~1~", emailModel.Subject);
        //    MailText = MailText.Replace("~2~", ticketBody);
        //    MailText = MailText.Replace("~3~", "Voleergo Solution LLP");
        //    return MailText;
        //}

        ///* ---------------------------------------------------------*/

        //public static string UserRegistration(string templatePath, List<string> arg)
        //{
        //    NotificationTask notificationTask = new NotificationTask();           
        //    StreamReader str = new StreamReader(templatePath);
        //    string MailText = str.ReadToEnd();
        //    str.Close();
        //    MailText = MailText.Replace("~0~", arg[0]);           
        //    return MailText;
        //}
        //public static string UserIntimation(string templatePath, List<string> arg)
        //{
        //    NotificationTask notificationTask = new NotificationTask();
        //    StreamReader str = new StreamReader(templatePath);
        //    string MailText = str.ReadToEnd();
        //    str.Close();
        //    MailText = MailText.Replace("~0~", arg[0]);
        //    MailText = MailText.Replace("~1~", arg[1]);
        //    MailText = MailText.Replace("~2~", arg[2]);
        //    return MailText;
        //}


        //public static string GenerateURL(Ticket ticket, string baseUrl)
        //{
        //    string returnUrl = "/Ticket/TicketEmailView?sid=" + Cryptography.EncryptBase64("emailview") + "&sid1=" + Cryptography.EncryptBase64(ticket.ID_Ticket.ToString());
        //    return Cryptography.EncryptBase64(returnUrl);

          
        //}
    }
}
