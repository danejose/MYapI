﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VT.Common
{
    public static class ActionModes
    {
        public static string VALIDATE_PWD = "VALIDATEFPWD";
        public static string UPDATE_PWD = "UPDATEFPWD";     

    }
}
