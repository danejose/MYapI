﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;

namespace VT.Common
{
    public static class DataConverter
    {
        public static byte[] ConvertToByteArray(string str)
        {
            return Encoding.ASCII.GetBytes(str);
        }
        public static string ConvertToString(byte[] btr)
        {
            return Encoding.ASCII.GetString(btr);
        }
    }
}
