﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace VT.Common
{
    public static class Network
    {
        //public static IPAddress GetIPAddress(string hostName)
        //{
        //    Ping ping = new Ping();
        //    var replay = ping.Send(hostName);

        //    if (replay.Status == IPStatus.Success)
        //    {
        //        return replay.Address;
        //    }
        //    return null;
        //}
        
    }
}
