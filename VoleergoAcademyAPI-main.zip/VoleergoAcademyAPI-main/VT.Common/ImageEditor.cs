﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using VT.Common;

namespace VT.Common
{
    public static class ImageEditor
    {
        public static string ConvertToImageBase64(string imgFile)
        {
            return "<img src=\"data:image/"
                        + Path.GetExtension(imgFile).Replace(".", "")
                        + ";base64,"
                        + Convert.ToBase64String(File.ReadAllBytes(imgFile)) + "\" />";
        }

        public static string WriteImagetoFile(string url, string token, string filePath)
        {
            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                using (Stream stream = client.GetStreamAsync(url).Result)
                {
                    StreamFileWriter.WriteStreamToFile(stream, filePath);
                }
            }
            return filePath;
        }
        public static void ConvertToUrl(string baseUrl,string fileName)
        {
            string emailLink = baseUrl + fileName;
        }
    }
}
