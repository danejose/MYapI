﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace VT.Common
{
    public static class StreamFileWriter
    {       
        public static string WriteStreamToFile(Stream stream, string destPath)
        {
            try
            {
                using (var fileStream = new FileStream(destPath, FileMode.Create, FileAccess.Write))
                {
                    stream.CopyTo(fileStream);
                }
                return destPath;
            }
            catch (Exception e)
            {
                throw new Exception("Failed");
            }
            
        }

    }
}
