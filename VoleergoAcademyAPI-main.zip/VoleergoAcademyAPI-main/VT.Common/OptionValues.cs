﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace VT.Common
{
    public class OptionValues
    {
        [JsonProperty("value")]
        public string Value { get; set; }
        [JsonProperty("text")]
        public string Text { get; set; }

        public OptionValues()
        {
            Value = string.Empty;
            Text = string.Empty;
        }
    }
}
