﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace VT.Common
{
    public static class ObjectEtender
    {
        public static T CheckNullvalues<T>(T data)
        {
            T obj = default(T);
            obj = Activator.CreateInstance<T>();
            foreach (PropertyInfo prop in obj.GetType().GetProperties())
            {
                System.Reflection.PropertyInfo p = typeof(T).GetProperty(prop.Name);
                Type type = p.PropertyType;
                try
                {
                    if (prop.CanRead)
                    {
                        object val = prop.GetValue(data, null);
                        System.TypeCode typeCode = System.Type.GetTypeCode(type);

                        if (val == null)
                        {
                            switch (typeCode)
                            {
                                case TypeCode.Int32:
                                    prop.SetValue(obj, 0, null);
                                    break;
                                case TypeCode.Int64:
                                    prop.SetValue(obj, 0, null);
                                    break;
                                case TypeCode.String:
                                    prop.SetValue(obj, "", null);
                                    break;
                            }

                        }
                        else
                        {
                            prop.SetValue(obj, val, null);
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }
            return obj;
        }
    }   
}
